export class ReqDetails {
    'draftTaskId'?: any;
    'overideSavedByID'?: any;
    'overideSavedByName'?: any;
    'requisition': Requisition;
    'requestor': Requestor;
    'territoryManager': TerritoryManager;
    'customers': TaskInboxCustomer[];
    'products': TaskInboxProduct[];
    'auditLogs': AuditLog[];
    'taskId'?: any;
    'taskName'?: string;
    'taskStatus'?: string;
    'responseStatus'?: any;
    'responseStatusDescription'?: any;
    'assignedToCount': string;
    'assignedToList': string[];

    constructor() {
        this.draftTaskId = '';
        this.overideSavedByID = '';
        this.overideSavedByName = '';
        this.requisition = {
            'requisitionNumber': '',
            'requisitionType': '',
            'division': '',
            'status': '',
            'createdAt': '',
            'updatedAt':  '',
            'totalAmount':  '',
            'ETASelection': false,
            'ETADate':  '',
            'returnIfETANotMet': false,
            'defaultShipMethod':  '',
            'defaultCustomerPO':  '',
            'defaultSpecInstructions':  '',
            'mainCustomerID':  '',
            'mainCustomerName':  '',
            'mainCustomerDept':  '',
            'mainCustomerType': '',
            'quotePrice':  '',
            'quoteNumber':  '',
            'comments': []
        };
        this.requestor = {
            'name': '',
            'networkId': '',
            'email': '',
            'phone': 'None',
            'additionalPhone': 'None',
            'additionalEmail': 'None'
        };
        this.territoryManager = {
            'name': '',
            'networkId': '',
            'email': 'None',
            'phone': 'None',
            'additionalPhone': '',
            'additionalEmail': ''
        };
        this.customers = new Array<TaskInboxCustomer>();
        this.products = new Array<TaskInboxProduct>();
        this.auditLogs = [];
    }

    // comments, shipto goes in products
}
export interface Requisition {
    'requisitionNumber': string;
    'requisitionType': string;
    'division': string;
    'status':  string;
    'createdAt':  string;
    'updatedAt':  string;
    'totalAmount':  any;
    'ETASelection': boolean;
    'ETADate':  string;
    'returnIfETANotMet': boolean;
    'defaultShipMethod':  string;
    'defaultCustomerPO':  string;
    'defaultSpecInstructions':  string;
    'mainCustomerID':  string;
    'mainCustomerName':  string;
    'mainCustomerDept':  string;
    'mainCustomerType': string;
    'quotePrice':  any;
    'quoteNumber':  string;
    'comments': Comment[];
}

export interface AuditLog {
    'displayText': string;
    'dateTime': string;
    'networkId': string;
    'userName': string;
}

export interface Comment {
    'commentsText': string;
    'timestamp': string;
    'networkId': string;
    'name': string;
}

export interface Requestor {
    'name': string;
    'networkId': string;
    'email': string;
    'phone': string;
    'additionalPhone': string;
    'additionalEmail': string;
}

export interface TerritoryManager {
    'name': string;
    'networkId': string;
    'email': string;
    'phone': string;
    'additionalPhone': string;
    'additionalEmail': string;
}

export interface TaskInboxCustomer {
    'seq': string;
    'id': string;
    'dept': string;
    'defaultShipMethod': string;
    'name': string;
    'address1': string;
    'city': string;
    'state': string;
    'zip': string;
    'phone': string;
    'estimatedOrderAmt': string;
    'confidenceCode': string;
    'creditCheckStatus': boolean;
}

export interface TaskInboxProduct {
    'seq': any;
    'new': string; // boolean value is returned for if product is new or existing
    'productId': string;
    'manufacturerId': string;
    'description':string;
    'qty': any;
    'label': string;
    'packSize': string;
    'catchWeightInd': string;
    'netWeight': string;
    'status': string;
    'sellPrice': any;
    'salesUOM': string;
    'handling': any;
    'ETASelection': boolean;
    'ETA': string;
    'actualETA': string;
    'ETAUpdRC':string;
    'ETAUpdRCDesc':string;
    'meetsETA': boolean;
    'type': string;
    'class': string;
    'attached': string; // I = not attached in market
    'statusCode': string;
    'PONumber': string;
    'PODate': string;
    'cost': boolean;
    'priceUOM': string;
    'returned': boolean;
    'requested': Requested;
    'vendor': TaskInboxVendor;
    'shipTodistribution': ShipTodistribution[];
    'comments': Comment[];
    'attachmentsFlag': string;

}

export interface Requested {
    'description': string;
    'vendor': string;
    'mfrId': string;
    'label': string;
    'packSize': string;
    'type': string;
    'salesUOM': string;
    'comments': string;
}

export interface TaskInboxVendor {
    'vendorId': string;
    'vendorName': string;
    'vendorType': string;
    'buyerNumber': string;
    'buyerEmail': string;
    'buyerNetworkId': string;
    'POCreationMethod': string;
}

export interface ShipTodistribution{
    'customerId': string;
    'departmentId': string;
    'qty': any;
    'sellPrice': any;
    'handling': any;
    'shipMethod': string;
    'customerPO': string;
    'specialInstructions': string;
    'status': string;
    'shippedQty': any;
    'returnedQty': any;
    'salesOrderNumber': string;
    'salesOrderDate': string;
    'salesOrderQty': any;
    'deliveryDate': string;
    'invoiceNumber': string;
    'invoiceDate': string;
}