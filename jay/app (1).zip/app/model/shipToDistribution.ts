import { Customer, SAMPLECUSTOMER } from './customer';

export class ShipToDistribution {
    id: number;
    customer: Customer;
    customerId:string;
    departmentId: string;
    qty: string;
    sellPrice: string;
    handling: string;
    shipMethod: string;
    customerPO: string;
    specialInstructions: string;
    status: string;
    shippedQty: string;
    returnedQty: string;
    salesOrderNumer: string;
    salesOrderDate: Date;
    salesOrderQty: string;
    deliveryDate: Date;
    InvoiceNumber: string;
    InvoiceDate: Date;
    //validation error
    sellPrice_number_error: boolean;
    qty_number_error: boolean;
    disableInput: boolean;

}

export const SAMPLEShipTo_1 : ShipToDistribution = {
    id: 1,
    customer: SAMPLECUSTOMER,
    customerId:'123',
    departmentId: '10-FOOD',
    qty: '1',
    sellPrice: '1.0',
    handling: '1', 
    shipMethod: 'Next',
    customerPO: 'testCustomerPO',
    specialInstructions: 'testSpecialInstructions',
    status: '',
    shippedQty: '',
    returnedQty: '',
    salesOrderNumer: '',
    salesOrderDate: new Date(),
    salesOrderQty: '',
    deliveryDate: new Date(),
    InvoiceNumber: '',
    InvoiceDate: new Date(),
    sellPrice_number_error: false,
    qty_number_error: false,
    disableInput: false
}

export const SAMPLEShipTo_2 : ShipToDistribution = {
    id: 2,
    customer: SAMPLECUSTOMER,
    customerId:'345',
    departmentId: '10-FOOD',
    qty: '2',
    sellPrice: '2.0',
    handling: '2', 
    shipMethod: 'Next',
    customerPO: 'testCustomerPO_2',
    specialInstructions: 'testSpecialInstructions',
    status: '',
    shippedQty: '',
    returnedQty: '',
    salesOrderNumer: '',
    salesOrderDate: new Date(),
    salesOrderQty: '',
    deliveryDate: new Date(),
    InvoiceNumber: '',
    InvoiceDate: new Date(),
    sellPrice_number_error: false,
    qty_number_error: false,
    disableInput: false
}

export const SAMPLEShipToArr: ShipToDistribution[] = [SAMPLEShipTo_1, SAMPLEShipTo_2];