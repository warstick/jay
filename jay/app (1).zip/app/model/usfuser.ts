export class UsfUser {
    userId: any;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
}

export const SAMPLEUSER: UsfUser = {
    userId: 'I1H6026',
    firstName: 'Sample',
    lastName: 'Name',
    email: 'test.user@usfoods.com',
    phone: '1234567890'
}