export class Approver {
    action: string;
    applicationId: string;
    division: string;
    roleId: string;
    roleID: string;
    level: string;
    userId: string;
    firstName: string;
    lastName: string;
    email: string;
    outofOffice: string;
    designatedId: string;
    returnDate: string;
    messages: Message[];
    roleName: string;
    valid: string;
    flag: boolean;
    
    static findInArray(array, property, value, property2, value2, property3, value3) {
        return array.filter((obj) => {
            return obj[property] === value && obj[property2] === value2 && obj[property3] === value3;
        });
    }

    static findIndexInArray(array, property, value, property2, value2, property3, value3) {
        return array.findIndex(x => x[property] === value && x[property2] == value2 && x[property3] === value3);
    }

    static findIndex(array, property, value) {
        return array.findIndex(x => x[property] === value);
    }

    constructor() {
        const messageArray = new Array<Message>();
        messageArray.push(new Message());
        this.action = '';
        this.applicationId = '1';
        this.division = '';
        this.roleId = '';
        this.level = '';
        this.userId = '';
        this.firstName = '';
        this.lastName = '';
        this.email = '';
        this.outofOffice = 'false';
        this.designatedId = '';
        this.returnDate = '';
        this.messages = messageArray;
        this.valid = 'false';
    }
}

export class Message {
    type: string;
    desc: string;

    constructor() {
        this.type = '';
        this.desc = '';
    }
}
