export class UnsetOutOfOfficeContent{
    NetworkID: string;
}

export class UnsetOutOfOffice{
    unsetOoOrequest: UnsetOutOfOfficeContent;
}

export class SetOutOfOfficeContent{
    OutOfOfficeUserID: string;
    ReturnDate:  string;
    DesignateID: string;
    SuperUserID: string;
    updatedByUserID: string;
}

export class SetOutOfOffice{
    setOoOrequest: SetOutOfOfficeContent;
}

