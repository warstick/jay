import { RouterModule } from '@angular/router';
import { MarketrolemanagerComponent } from './marketrolemanager.component';
import { AuthGuard } from '../util/auth.guard';

export const marketRoleManagerRoutes = [
    { path: '', component: MarketrolemanagerComponent, canActivate: [AuthGuard] }
];

export const routing = RouterModule.forChild(marketRoleManagerRoutes);