import { Component, OnInit } from '@angular/core';
import {BaseComponent} from '../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import {ActionEvents, ModelChangeUpdateEvents} from "../../events/action-events";

import { Requisition } from '../../model/requisition';
import { User } from '../../model/requisition';

@Component({
    selector: 'app-sodssearch',
    templateUrl: './sodssearch.component.html',
    styleUrls: ['./sodssearch.component.css']
})
export class SodssearchComponent extends BaseComponent implements OnInit {

    public searchText: string;
    public searchCriterias: String[];
    public searchOps: String[];

    //Data Model
    reqId: string;
    type: string;
    division: string;
    status: string;
    createdAt: string;
    updatedAt: string;
    totalAmount: string;
    etaSelection: string;
    etaDate: string;
    returnIfEtaNotMet: string;
    defaultShipMethod: string;
    defaultCustomerPO: string;
    defaultSpecInstructions: string;
    rejectComment: string;
    mainCustomerID: string;
    mainCustomerName: string;
    mainCustomerDept: string;
    requestor: User;
    tm: User;

    public reqList:Array<Requisition> = [];

    constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
        super(stateRepresentationRendererService);
    }

    ngOnInit() {

        //Test Init Data
        this.initData();

        let mapping: any = [];

        mapping[ModelChangeUpdateEvents.REQ_FOUNT] = (data: Requisition) => {
            this.renderReqFound(data);
        }

        mapping[ModelChangeUpdateEvents.REQ_NOT_FOUND] = (error: any) => {

        }

        super.registerStateChangeEvents(mapping);

    }

    public initData(){
        this.searchCriterias = ["Requisition", "Division"];
        this.searchOps = ["Equals", "Greater than", "Less than", "Greater than equal to", "Less than equal to"];
    }

    public searchChanged($event):void{
		console.log("search Text hitting");
        let event = this.actionDispatcherService.generateEvent('sodsRequestToLoadReq', {reqId: this.searchText});
        this.actionDispatcherService.dispatch(event);
	}

    public goToDetails(reqId: String): void{
        console.log(reqId);
        window.open("sodsdetails/" + reqId, '_blank', 'width=500, height=400');
    }

    renderReqFound(req: Requisition){
        this.reqId = req.reqId;
        this.type = req.type;
        this.division = req.division;
        this.status = req.status;
        this.updatedAt = req.updatedAt;
        this.defaultSpecInstructions = req.defaultSpecInstructions;
        this.defaultCustomerPO = req.defaultCustomerPO;
        this.defaultShipMethod = req.defaultShipMethod;
        this.mainCustomerDept = req.mainCustomerDept;
        this.mainCustomerID = req.mainCustomerID;
        this.mainCustomerName = req.mainCustomerName;
        this.totalAmount = req.totalAmount;
        this.tm = req.tm;
        this.requestor = req.requestor;
        this.reqList.push(req);
    }

}
