import { RouterModule } from '@angular/router';
import { SodssearchComponent } from './sodssearch.component';
import { AuthGuard } from '../util/auth.guard';

export const sodsSearchRoutes=[
    { path: '', component: SodssearchComponent, canActivate: [AuthGuard] }
];

export const routing = RouterModule.forChild(sodsSearchRoutes);