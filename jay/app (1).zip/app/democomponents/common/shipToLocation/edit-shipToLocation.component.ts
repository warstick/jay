import { Component, OnInit, ViewChild, Output, Input, AfterContentChecked , EventEmitter} from '@angular/core'; 
import { Modal, ModalModule } from 'ngx-modal';
import {ActionEvents, ModelChangeUpdateEvents} from "../../../events/action-events";
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { BaseComponent } from '../../base-component';
import { Customer } from '../../../model/customer';
import { DropdownComponent } from "app/democomponents/common/dropdown/dropdown.component";


@Component({
  selector: 'sods-edit-shipToLocation',
  templateUrl: './edit-shipToLocation.component.html',
  styleUrls: ['./edit-shipToLocation.component.css']
})

export class EditShipToLocationComponent extends BaseComponent implements OnInit, AfterContentChecked {

    @Input() selectedMarket: any;
    @Input() options: any;
    private shipOptions: string[] = ['Next', 'Separate'];
    marketingOptions: any = [];
    
    // seq: string;
    id: string;
    division: string;
    dept: string;
    name: string;
    defaultShipMethod: string;
    address: string;
    postalInfo: string;
    phone: string;
    comments: string;
    specialInstruct: string;
    estimatedOrderAmt: string;
    confidenceCode: string;
    creditCheckStatus: string;
    marketOptions : any = [];
    deptOptions: any = [];
    divisionObj : Object;
    dataloaded: boolean = false;
    public defaultDept: string;
    selectedDept: any = '';
    dataChanged: boolean = false;
    customerNo: any;
    hasDuplicate = false;

    customerPo: any;
    invalidId = false;
    disabled: any = false;
    duplicate: any = false;
    error: any = false;
    idChanged: any = false;

    defaultShip: string = 'Next';
    selectedShip: string = 'Next';

    city: string;
    state: string;
    zip: string;

    @ViewChild('ProdTypeDropdown1') prodTypeDropdown1: DropdownComponent;
    @ViewChild('ProdTypeDropdown2') prodTypeDropdown2: DropdownComponent;
    counter1 = 1;
    counter2 = 1;
    
    constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
        super(stateRepresentationRendererService);
    }
  
    ngOnInit() {
    }

    ngAfterContentChecked() {
    }


    getMarketName() {
        if (!this.options) {
            return ''
        }
        const item = this.options.find((item) => {
            return item.divisionNumber === this.selectedMarket;
        })
        return item ? item.distributionName + '('+ item.divisionCode +', ' + item.divisionNumber +')' : ''
    }

    retreiveCustomer(){
        try{
                        this.duplicate = false;
            this.dataChanged = true;
            console.log("Call Retreive Customer Action");
            this.dataloaded = false;
            this.idChanged = false;
            let event = this.actionDispatcherService.generateEvent(ActionEvents.RETRIEVE_CUST_SHIPTO, {id: this.id, division: this.selectedMarket});
            this.actionDispatcherService.dispatch(event);
        }catch(err) {

        }

    }

    onIdChange() {
        console.log(this.id);
        if (isNaN(Number(this.id)) || this.id.toString().length !== 8) {
            this.error = false;
            this.invalidId = true;
        } else {
            this.invalidId = false;
        }
        this.idChanged = true;
    }

    onDeptSelection($event){
        this.duplicate = false;
        this.dataChanged = true;
        this.selectedDept = $event;
        console.log("Selected Department is " + this.selectedDept);
    }

    onShipmentSelection($event){
        this.dataChanged = true;
        this.duplicate = false;
        this.selectedShip = $event;
        console.log("Selected Department is " + this.selectedShip);
    }

    resetValues() {
        console.log('we are here');
        this.id = null;
        this.idChanged = false;
        this.invalidId = false;
        this.selectedDept = null;
        this.selectedShip = null;
        this.customerPo = null;
        this.specialInstruct = null;
        this.dataloaded = false;
        this.disabled = false;
        this.dataChanged = false;
        this.duplicate = false;
        this.error = false;
        this.dataChanged = false;
        this.hasDuplicate = false;
    }

    controlClick(){
        if(this.counter1 % 2 == 0 && this.prodTypeDropdown1.isVisible){
          this.prodTypeDropdown1.isVisible = false;
          this.counter1 ++;
        }else if(this.prodTypeDropdown1.isVisible){
          this.counter1 ++;
        }else if(this.counter1 % 2 == 0 && !this.prodTypeDropdown1.isVisible){
          this.counter1 ++;
        }
    
        if(this.counter2 % 2 == 0 && this.prodTypeDropdown2.isVisible){
            this.prodTypeDropdown2.isVisible = false;
            this.counter2 ++;
          }else if(this.prodTypeDropdown2.isVisible){
            this.counter2 ++;
          }else if(this.counter2 % 2 == 0 && !this.prodTypeDropdown2.isVisible){
            this.counter2 ++;
          }
      }

}