import { Requested } from './../../../model/product';
import { Attachment } from './../../../model/attachment';
import { any } from 'codelyzer/util/function';
import { ProductAttachmentComponent } from './product-attachment.component';
import { Component, OnInit, ViewChild, Output, Input, EventEmitter } from '@angular/core'; 
import { Modal, ModalModule } from 'ngx-modal';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { BaseComponent } from '../../base-component';
import { AddNewProductComponent } from './add-new-product.component';
import { AddExistingProductComponent } from './add-existing-product.component';
import { ProductCommentComponent } from '../comment/product-comment/product-comment.component';
import { EditNewProductComponent } from './edit-new-product.component';
import { EditExistingProductComponent } from './edit-existing-product.component';
import { Customer } from '../../../model/customer';
import { Comment } from '../../../model/comment';

import { Product, SAMPLEProduct, SAMPLEProduct_B, Vendor } from '../../../model/product';
import {ActionEvents, ModelChangeUpdateEvents} from "../../../events/action-events";
import {SAMPLEShipToArr, ShipToDistribution} from '../../../model/shipToDistribution';

@Component({
  selector: 'sods-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent extends BaseComponent implements OnInit {

  public products: Array<Product> = [];
  public delProduct: Product;
  public retrieveCustSuccss: boolean = false;
  public retrieveProductSuccess: boolean = false;
  public productCount: number = 1;


  public attachmentsList:Array<any> = [];
  public requisitionId : string;
  public globalAttachmentKey: number;

  //validation
  public sumUpErr: boolean = false;
  public shipto_sellPrice_number_error: boolean = false;
  public shipto_qty_number_error: boolean = false;

  //shipTo template
  public shipToArray: Array<ShipToDistribution> = [];

  @ViewChild('ProductNewAddModal')
  productNewAddModal: Modal;

  @ViewChild('ProductExistingAddModal')
  productExistingAddModal: Modal;

  @ViewChild('errorMsg')
  errorMsg: Modal;

  @ViewChild('ProductNewAdd')
  addNewProduct: AddNewProductComponent;

  @ViewChild('ProductAddExisting')
  addExistingProduct: AddExistingProductComponent;

  @ViewChild('removeLocation') removeLocationModal: Modal;

  //Product Attachment Modal
  @ViewChild('ProductAttachment')
  productAttachmentComponent: ProductAttachmentComponent;

  @ViewChild('ProductAttachmentModal')
  productAttachmentModal: Modal;

  //Add Comment Modal
  @ViewChild('ProductCommentAddModal') addProductCommentModal: Modal;
  @ViewChild('ProductComments') productComments: ProductCommentComponent; 

  //Edit New Product Modal
  @ViewChild('ProductEditNewModal') editProductNewModal: Modal;
  @ViewChild('ProductEditNew') editNewProductComponent: EditNewProductComponent;

  //Edit Existing Product Modal
  @ViewChild('ProductEditExistingModal') editProductExistingModal: Modal;
  @ViewChild('ProductEditExisting') editExistingProductComponent: EditExistingProductComponent;

  isCollapsedProduct: any = true;
  //dropdown box
  shipMethodsOptions: string[];
  private selectedShipMethod: string;
  //default value
  public defaultShipMethod: string = 'Next';
  public defaultCustomerPO: string = '';
  public defaultSpecInstructions: string = '';
  private textareaLength: number = 1000;

  modalTitle: string = '';
  modalMsg: string = '';

  constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
    super(stateRepresentationRendererService);
    let mapping: any = [];        
    mapping[ModelChangeUpdateEvents.CUST_FOUND] = (data: Customer) => { this.renderCustFound(); }
    mapping[ModelChangeUpdateEvents.RETRIEVE_PRODUCT_SUCCESS] = (product: Product) => { this.renderProductFound(product); }
    mapping[ModelChangeUpdateEvents.RETRIEVE_PRODUCT_FAIL] = (error: any) => { this.renderProductNotFound();}
    mapping[ModelChangeUpdateEvents.CALENDAR_CHANGE_SUCCESS] = (date: Date) => { this.renderCalendarChangeSuccess(date)}
    mapping[ModelChangeUpdateEvents.PROD_ATTACH_DETAILS_SUCCESS] = (data) => { this.renderAttachmentDetails(data) }    
    mapping[ModelChangeUpdateEvents.PROD_ATTACH_DOWNLOAD_SUCCESS] = () => { this.prodMultiDownloadSuccess() }
    mapping[ModelChangeUpdateEvents.PROD_ATTACH_DOWNLOAD_FAIL] = () => { this.prodMultiDownloadFail() }
    mapping[ModelChangeUpdateEvents.PROD_ATTACHMENTS_MULTI_DELETE_SUCCESS] = () => { this.prodMultiDeleteSuccess() }
    mapping[ModelChangeUpdateEvents.PROD_ATTACHMENTS_MULTI_DELETE_FAIL] = () => { this.prodMultiDeleteFail() }
    mapping[ModelChangeUpdateEvents.SHIPTO_CHANGE_SUCCESS] = (data: any) => {this.renderShipToChange(data)};
    mapping[ModelChangeUpdateEvents.DEPARTMENT_CHANGE_SUCCESS] = (deptId: string) => { this.renderDeptChangeSuccess(deptId); }
    mapping[ModelChangeUpdateEvents.SHIPMENT_CHANGE_SUCCESS] = (data: any) => { this.renderShipmentChangeSuccess(data); }

    super.registerStateChangeEvents(mapping);
  }

  ngOnInit() {
	  this.products = [];
    console.log(this.products);
    this.globalAttachmentKey = 0;
    this.attachmentsList = [];
    this.shipMethodsOptions = ['Next', 'Seperate'];
    this.requisitionId = this.addNewProduct.requisitionId;
    //this.addNewProduct.attachmentsList = [];
  }

  onShipMethodSelection(shipTo:ShipToDistribution, $event){
    shipTo.shipMethod = $event;
    if($event == 'Next'){
      shipTo.disableInput = true;
      shipTo.customerPO = '';
      shipTo.specialInstructions = '';
    }else{
      shipTo.disableInput = false;
    }
    console.log($event);
  }



  getProductsData() {
    return this.products.map((item) => {
      let prod = Object.assign({}, item);
      prod.shipTodistribution = prod.shipTodistribution.map((shipTo:ShipToDistribution) => {
        shipTo.customerId = shipTo.customer.id;
        return shipTo;
      });
      let requestedObj: Requested = new Requested;
      //If new item, add requested section, null out vendor section
      if(item.new) {
        requestedObj.description = item.description;
        requestedObj.vendor = item.vendor.vendorName;
        requestedObj.mfrId = item.mfrId;
        requestedObj.label = item.label;
        requestedObj.packSize = item.packSize;
        requestedObj.type = item.prodType;
        if(item.comments[0] != null && item.comments[0] != undefined){
          requestedObj.comments = item.comments[0].commentsText;
        }
        prod.requested = requestedObj;
        prod.vendor = null;
      }
       //If existing product, add vendor section, null out requested section
      if(!item.new) {
        prod.cost = item.vendor.vendorLstPrc;
        prod.vendor.vendorId = item.vendor.vendorId;
        prod.vendor.vendorName = item.vendor.vendorName;
        prod.vendor.vendorLstPrc = item.vendor.vendorLstPrc;
        prod.vendor.buyerNumber = item.vendor.buyerNumber;
        prod.vendor.buyerEmail = item.vendor.buyerEmail;
        prod.vendor.buyerNetworkId = item.vendor.buyerNetworkId;
        prod.requested = null;
      }
      prod.type = item.prodType;
      if(item.eta != null && item.eta != undefined){
        prod.ETA = this.getDateFormat(item.eta);
      }
      prod.manufacturerId = item.mfrId;
      console.log("Get Product Data: " + JSON.stringify(prod));
      return prod;
    });
  }

  openAddNew(){
    this.addNewProduct.product.new = true;
    this.addNewProduct.product.comments = new Array<Comment>();
    this.addNewProduct.product.attachments = new Array<Attachment>();
    this.addNewProduct.comment.commentsText = null;
    this.addNewProduct.product.prodType = this.addNewProduct.defaultProdType;
    this.addNewProduct.prodTypeDropdown.selectedOption = this.addNewProduct.defaultProdType;
    this.addNewProduct.attachmentsList = [];
    this.addNewProduct.product.seq = this.productCount ;
    this.attachmentsList = [];
    this.globalAttachmentKey += 1;
    this.addNewProduct.product.attachmentKey = this.globalAttachmentKey;
    this.addNewProduct.product.seq = this.productCount;
    this.addNewProduct.errorOnUpload = false;
    this.productNewAddModal.open();
  }

  closeAddNew(){
    //Clean out the component
    this.addNewProduct.product = new Product();
    this.addNewProduct.product.vendor = new Vendor();
    this.addNewProduct.product_desc_require_error = false;
    this.addNewProduct.mfr_product_require_error = false;
    this.addNewProduct.qty_number_error = false;
    this.addNewProduct.qty_require_error = false;
    this.addNewProduct.zero_number_error = false;
    this.addNewProduct.vendor_require_error = false;
    this.addNewProduct.sellPrice_number_error = false;
    this.productNewAddModal.close();
    this.productAttachmentModal.close();

    this.addNewProduct.product.seq = this.productCount;
  }

  cancelAddNew(){
    //Clean out the code
    this.addNewProduct.product = new Product();
    this.addNewProduct.product.vendor = new Vendor();
    this.addNewProduct.product_desc_require_error = false;
    this.addNewProduct.mfr_product_require_error = false;
    this.addNewProduct.qty_number_error = false;
    this.addNewProduct.qty_require_error = false;
    this.addNewProduct.zero_number_error = false;
    this.addNewProduct.vendor_require_error = false;
    this.addNewProduct.sellPrice_number_error = false;
    this.productNewAddModal.close();
  }

  openAddExisting(){
    this.productExistingAddModal.open();
    this.addExistingProduct.errMsg = "";
    // this.addExistingProduct.errMsg = "";
    this.addExistingProduct.product.new = false;
    this.addExistingProduct.product.comments = new Array<Comment>();
    this.addExistingProduct.product.attachments = new Array<Attachment>();
    this.addExistingProduct.product.prodType = this.addExistingProduct.defaultSearchType;
    this.addExistingProduct.prodTypeDropdown.selectedOption = this.addExistingProduct.defaultSearchType;
  }

  closeAddExisting(){
    this.addExistingProduct.retrieveSuccess = false;
    this.addExistingProduct.product_not_found_error = false;
    this.addExistingProduct.duplicated_product_error = false;
    this.addExistingProduct.sellPrice_number_error = false;
    this.addExistingProduct.handling_number_error = false;
    this.addExistingProduct.qty_require_error = false;
    this.addExistingProduct.qty_number_error = false;
    this.addExistingProduct.zero_number_error = false;
    this.retrieveProductSuccess = false;
    this.addExistingProduct.productNbr = '';
    this.productExistingAddModal.close();
  }

  cancelAddExisting(){
    this.addExistingProduct.retrieveSuccess = false;
    this.addExistingProduct.product_not_found_error = false;
    this.addExistingProduct.duplicated_product_error = false;
    this.addExistingProduct.sellPrice_number_error = false;
    this.addExistingProduct.handling_number_error = false;
    this.addExistingProduct.qty_require_error = false;
    this.addExistingProduct.qty_number_error = false;
    this.addExistingProduct.zero_number_error = false;
    this.retrieveProductSuccess = false;
    this.addExistingProduct.productNbr = '';
    this.productExistingAddModal.close();
  }

  addAndSave(){

    //Test Duplicate Check
    if(this.dataHasDuplicateValue(this.addExistingProduct.product)){
      this.addExistingProduct.duplicated_product_error = true;
    }else{
      this.addExistingProduct.qty_require_error = 
        ((this.addExistingProduct.product.qty == null || this.addExistingProduct.product.qty == undefined) ? true : false);
      if(this.addExistingProduct.qty_require_error){
        return;
      }

      //Validation
      this.addExistingProduct.checkSellPrice();
      this.addExistingProduct.checkHandlingPrice();
      this.addExistingProduct.checkNumberFormatforQty();
      this.addExistingProduct.checkKeyupRequire_qty();

      if(this.addExistingProduct.sellPrice_number_error || 
        this.addExistingProduct.handling_number_error || 
        this.addExistingProduct.qty_number_error ||
        this.addExistingProduct.qty_require_error ||
        this.addExistingProduct.zero_number_error){
          return;
      }

      //add validation for ordering multiples here
      if(this.editExistingProductComponent.product.convFctr != null && this.editExistingProductComponent.product.convFctr != undefined){
        if(Number(this.addExistingProduct.product.qty) % Number(this.addExistingProduct.product.convFctr) != 0){
          this.addExistingProduct.errMsg = 'Quantity must be entered in multiples of ' + this.addExistingProduct.product.convFctr;
          return;
        }
      }

      //initialize the each shipTo component
      if(this.shipToArray.length == 1){
        this.shipToArray[0].qty = this.addExistingProduct.product.qty;
        this.sumUpErr = false;
        this.shipToArray[0].shipMethod = this.defaultShipMethod;
        this.shipToArray[0].customerPO = this.defaultCustomerPO;
        this.shipToArray[0].specialInstructions = this.defaultSpecInstructions;
        this.shipToArray[0].sellPrice = this.addExistingProduct.product.sellPrice; 
        if(this.shipToArray[0].shipMethod == 'Next'){
          this.shipToArray[0].disableInput = true;
        }else{
          this.shipToArray[0].disableInput = false;
        }
      }else{
        this.shipToArray.forEach((shipTo, index) => {
          //SOBI-1426
          shipTo.qty = "0";
          this.sumUpErr = true;
          shipTo.sellPrice = this.addExistingProduct.product.sellPrice; 
          if(shipTo.shipMethod == 'Next'){
            shipTo.disableInput = true;
          }else{
            shipTo.disableInput = false;
          }
        });
      }
      this.addExistingProduct.product.seq = this.productCount;
      this.productCount += 1;
      //Test sample shipto array
      this.addExistingProduct.product.shipTodistribution = this.shipToArray.map(x => Object.assign({}, x));
      //we need to push the value into eta
      if(this.addExistingProduct.product.eta == null || this.addExistingProduct.product.eta == undefined){
        this.addExistingProduct.product.eta = this.addExistingProduct.value;
      }
      this.products.push(this.addExistingProduct.product);
      this.addExistingProduct.product = new Product();
      this.addExistingProduct.product.vendor =  new Vendor();
      this.addExistingProduct.retrieveSuccess = false;
      this.addExistingProduct.product_not_found_error = false;
      this.addExistingProduct.productNbr = '';
      this.retrieveProductSuccess = false;
    }
    console.log("This is the added product" + JSON.stringify(this.addExistingProduct.product));
  }

  addExisting(){
    if(this.dataHasDuplicateValue(this.addExistingProduct.product)){
      this.addExistingProduct.duplicated_product_error = true;
    }else{
      this.addExistingProduct.qty_require_error = 
        ((this.addExistingProduct.product.qty == null || this.addExistingProduct.product.qty == undefined) ? true : false);
      if(this.addExistingProduct.qty_require_error){
        return;
      }

      //Validation
      this.addExistingProduct.checkSellPrice();
      this.addExistingProduct.checkHandlingPrice();
      this.addExistingProduct.checkNumberFormatforQty();
      this.addExistingProduct.checkKeyupRequire_qty();

      if(this.addExistingProduct.sellPrice_number_error || 
        this.addExistingProduct.handling_number_error || 
        this.addExistingProduct.qty_number_error ||
        this.addExistingProduct.qty_require_error ||
        this.addExistingProduct.zero_number_error){
          return;
      }

      //add validation for ordering multiples here
      if(this.editExistingProductComponent.product.convFctr != null && this.editExistingProductComponent.product.convFctr != undefined){
        if(Number(this.addExistingProduct.product.qty) % Number(this.addExistingProduct.product.convFctr) != 0){
          this.addExistingProduct.errMsg = 'Quantity must be entered in multiples of ' + this.addExistingProduct.product.convFctr;
          return;
        }
      }


      //initialize the each shipTo component
      if(this.shipToArray.length == 1){
        this.shipToArray[0].qty = this.addExistingProduct.product.qty;
        this.sumUpErr = false;
        this.shipToArray[0].shipMethod = this.defaultShipMethod;
        this.shipToArray[0].customerPO = this.defaultCustomerPO;
        this.shipToArray[0].specialInstructions = this.defaultSpecInstructions;
        this.shipToArray[0].sellPrice = this.addExistingProduct.product.sellPrice; 
        if(this.shipToArray[0].shipMethod == 'Next'){
          this.shipToArray[0].disableInput = true;
        }else{
          this.shipToArray[0].disableInput = false;
        }
      }else{
        this.shipToArray.forEach((shipTo, index) => {
          //SOBI-1426
          //shipTo.qty = this.addExistingProduct.product.qty;
          shipTo.qty = "0";
          this.sumUpErr = true;
          shipTo.sellPrice = this.addExistingProduct.product.sellPrice; 
          if(shipTo.shipMethod == 'Next'){
            shipTo.disableInput = true;
          }else{
            shipTo.disableInput = false;
          }
        });
      }


      //reset addExistingProductWindow
      this.addExistingProduct.product.seq = this.productCount;
      this.productCount += 1;
      //Test sample ship to array
      this.addExistingProduct.product.shipTodistribution = this.shipToArray.map(x => Object.assign({}, x));
      //we need to push the value into eta
      if(this.addExistingProduct.product.eta == null || this.addExistingProduct.product.eta == undefined){
        this.addExistingProduct.product.eta = this.addExistingProduct.value;
      }
      this.products.push(this.addExistingProduct.product);
      this.addExistingProduct.product = new Product();
      this.addExistingProduct.product.vendor =  new Vendor();
      this.addExistingProduct.product_not_found_error = false;
      this.addExistingProduct.retrieveSuccess = false;
      this.addExistingProduct.productNbr = '';
      this.retrieveProductSuccess = false;
      this.closeAddExisting();
    }
    console.log(JSON.stringify(this.products))
  }

  addNew(){
    debugger
    //Validation happens here
    //Validate the require field
    this.addNewProduct.product_desc_require_error = 
      ((this.addNewProduct.product.description == null || 
        this.addNewProduct.product.description == undefined || 
        this.addNewProduct.product.description.trim() == '') ? true : false);

    this.addNewProduct.mfr_product_require_error = 
      ((this.addNewProduct.product.mfrId == null || 
        this.addNewProduct.product.mfrId == undefined ||
        this.addNewProduct.product.mfrId.trim() == '') ? true : false);

    this.addNewProduct.qty_require_error = 
      ((this.addNewProduct.product.qty == null || 
        this.addNewProduct.product.qty == undefined ||
        this.addNewProduct.product.qty == '') ? true : false);

    this.addNewProduct.vendor_require_error = 
      ((this.addNewProduct.product.vendor.vendorName == null || 
        this.addNewProduct.product.vendor.vendorName == undefined ||
        this.addNewProduct.product.vendor.vendorName.trim() == '') ? true : false);

    if(this.addNewProduct.product_desc_require_error || 
        this.addNewProduct.mfr_product_require_error || 
        this.addNewProduct.vendor_require_error ||
        this.addNewProduct.qty_require_error || 
        this.addNewProduct.qty_number_error ||
        this.addNewProduct.sellPrice_number_error ){
      return;
    }

	  // if(this.addNewProduct.product.vendor == null || this.addNewProduct.product.vendor == undefined){
		//   this.addNewProduct.product.vendor = new Vendor();
    // }

    this.addNewProduct.product.seq = this.productCount;
    this.addNewProduct.product.attachCount = this.addNewProduct.attachmentsList.length;

    this.productCount += 1;
    if(this.addNewProduct.comment.commentsText != null &&  this.addNewProduct.comment.commentsText != undefined && this.addNewProduct.comment.commentsText != ''){
      this.addNewProduct.product.comments.push(Object.assign({}, this.addNewProduct.comment));
    }


    //initialize the each shipTo component
    if(this.shipToArray.length == 1){
      this.shipToArray[0].qty = this.addNewProduct.product.qty;
      this.sumUpErr = false;
      this.shipToArray[0].sellPrice = this.addNewProduct.product.sellPrice; 
      if(this.shipToArray[0].shipMethod == 'Next'){
        this.shipToArray[0].disableInput = true;
      }else{
        this.shipToArray[0].disableInput = false;
      }
    }else{
      this.shipToArray.forEach((shipTo, index) => {
        //SOBI-1426
        //shipTo.qty = this.addNewProduct.product.qty;
        shipTo.qty = "0";
        this.sumUpErr = true;
        shipTo.sellPrice = this.addNewProduct.product.sellPrice; 
        if(shipTo.shipMethod == 'Next'){
          shipTo.disableInput = true;
        }else{
          shipTo.disableInput = false;
        }
      });
    }


    this.products.forEach((product, index) => {
      if (this.delProduct && this.delProduct.description == product.description) {
          this.products.splice(index, 1);
          this.delProduct = null;
          this.removeLocationModal.close();  
      }    
  });
  
    this.addNewProduct.product.shipTodistribution = this.shipToArray.map(x => Object.assign({}, x));
    this.products.push(this.addNewProduct.product);
	  this.closeAddNew();
  }

  get productsCount() {
	  return (this.products).length;
  }

  renderCustFound(){
    this.retrieveCustSuccss = true;
  }

  closeWarningPopup() {
    this.errorMsg.close();
  }

  renderProductFound(product: Product){
    if(product.distSts.toString() === ''){
      this.retrieveProductSuccess = true;
    }
    else if (Number(product.distSts) === 0 || Number(product.distSts) === 2 
      || Number(product.distSts) === 3 || Number(product.distSts) ===  4 
      || Number(product.distSts) === 8 || Number(product.distSts) === 9) {
        this.retrieveProductSuccess = false;
    } else{
      this.retrieveProductSuccess = true;
    }
  }

  renderProductNotFound(){
    this.retrieveProductSuccess = false;
  }

  renderCalendarChangeSuccess(date: Date){
    //Initialize the eta of product object
    this.addExistingProduct.value = date;
    this.addNewProduct.value = date;
    this.addNewProduct.product.eta = date;
    this.addExistingProduct.product.eta = date;
    //Reset all values in the tables
    if(this.products != null && this.products != undefined && this.products.length > 0){
      for(let i = 0; i < this.products.length; i++){
        this.products[i].eta = date;
      }
    }
  }

  dataHasDuplicateValue(item: Product) {
    const isAlreadyExist = this.products.find((product) => {
      return (
           product.productId === item.productId
      )
  });     
  return (isAlreadyExist) ? true: false;
}

dataHasDuplicateValueforEdit(item: Product) {
  const isAlreadyExist = this.products.find((product) => {    
    if(product.seq != item.seq){
      return (
          product.productId === item.productId
      )
    }else{
      return false;
    }
  });     
  return (isAlreadyExist) ? true: false;
  }

closeRemove(){
  this.removeLocationModal.close();
}

removeProduct(product:Product) {
  this.delProduct = product;
  this.removeLocationModal.open();     
}

remove() {
  this.products.forEach((product, index) => {
      if (this.delProduct && this.delProduct.description == product.description) {
          this.products.splice(index, 1);
          this.delProduct = null;
          this.removeLocationModal.close();  
      }    
  });
}

openAddComment(product: Product){
  this.addProductCommentModal.open();
  this.productComments.newAddedCount = 0;
  this.productComments.comments = product.comments;
  this.productComments.productSeq = product.seq;
}

closeComment(){
  // if user has hit the add button
  if(this.productComments.newAddFlag == true){
    //cancel without saving so clear out the first item of the comments array
    for(let i = 0; i < this.productComments.newAddedCount; i++){
      this.productComments.comments.shift();
    }
    //reset the add flag
    this.productComments.newAddFlag = false;
  }
  //clear error
  this.productComments.commentErr = false;
  this.addProductCommentModal.close();
}

//save Comment
saveComment(){
  //validation first
  if(this.productComments.commentErr == true){
    return;
  }
  //if user does not hit add, just close it
  if(this.productComments.newAddFlag == false){
    this.addProductCommentModal.close();
  }else{
    this.productComments.newAddFlag = false;
    //save to comments array of product element
    this.products.forEach((product, index) => {
      if (product.seq == this.productComments.productSeq) {
        //will need to remove the empty text on the first element
        if(this.productComments.comments[0].commentsText == ''){
          this.productComments.comments.shift();
        }
        product.comments = this.productComments.comments;
      }    
    });
    this.addProductCommentModal.close();
  }
}

editProduct(product: Product){
  
  if(product.new == true){    
    this.editNewProductComponent.product.seq = product.seq;
    this.editNewProductComponent.product.productId = product.productId;
    this.editNewProductComponent.product.description = product.description;
    this.editNewProductComponent.product.eta = product.eta;
    this.editNewProductComponent.product.mfrId = product.mfrId;
    this.editNewProductComponent.product.packSize = product.packSize;
    this.editNewProductComponent.product.salesUOM = product.salesUOM;
    this.editNewProductComponent.product.sellPrice = product.sellPrice;
    this.editNewProductComponent.product.qty = product.qty;
    this.editNewProductComponent.product.label = product.label;
    this.editNewProductComponent.value = product.eta;
    this.editNewProductComponent.product.prodType = product.prodType;
    this.editNewProductComponent.defaultProdType = product.prodType;
    this.editNewProductComponent.product.vendor.vendorName = product.vendor.vendorName;
    this.editNewProductComponent.product.vendor.vendorId = product.vendor.vendorId;
    this.editNewProductComponent.product.attachments = product.attachments;
    this.editNewProductComponent.product.attachmentKey = product.attachmentKey;
    this.editNewProductComponent.attachmentsList = [];
    this.editNewProductComponent.tempDelete = [];
    let event = this.actionDispatcherService.generateEvent(ActionEvents.PROD_ATTACHMENT_DETAILS, {requisitionId: this.addNewProduct.requisitionId, attachmentKey:product.attachmentKey});
    this.actionDispatcherService.dispatch(event);

    this.editProductNewModal.open();
  }else{
    this.editExistingProductComponent.product.seq = product.seq;
    this.editExistingProductComponent.product.productId = product.productId;
    this.editExistingProductComponent.product.description = product.description;
    this.editExistingProductComponent.product.eta = product.eta;
    this.editExistingProductComponent.product.mfrId = product.mfrId;
    this.editExistingProductComponent.product.packSize = product.packSize;
    this.editExistingProductComponent.product.salesUOM = product.salesUOM;
    this.editExistingProductComponent.product.sellPrice = product.sellPrice;
    this.editExistingProductComponent.product.qty = product.qty;
    this.editExistingProductComponent.product.label = product.label;
    this.editExistingProductComponent.value = product.eta;
    this.editExistingProductComponent.product.vendor.vendorName = product.vendor.vendorName;
    this.editExistingProductComponent.product.vendor.vendorId = product.vendor.vendorId;
    this.editExistingProductComponent.product.handling = product.handling;
    this.editExistingProductComponent.retrieveSuccess = true;
    this.editExistingProductComponent.productNbr = product.productId;
    this.editNewProductComponent.product.attachmentKey = product.attachmentKey;
    this.editExistingProductComponent.errMsg = '';
    this.editExistingProductComponent.product.convFctr = product.convFctr;
    this.editProductExistingModal.open();
  }
}

editNewProduct(){

  this.editNewProductComponent.product_desc_require_error = 
  ((this.editNewProductComponent.product.description == null || 
    this.editNewProductComponent.product.description == undefined || 
    this.editNewProductComponent.product.description.trim() == '') ? true : false);

  this.editNewProductComponent.mfr_product_require_error = 
    ((this.editNewProductComponent.product.mfrId == null || 
      this.editNewProductComponent.product.mfrId == undefined || 
      this.editNewProductComponent.product.mfrId.trim() == '') ? true : false);

  this.editNewProductComponent.qty_require_error = 
    ((this.editNewProductComponent.product.qty == null || 
      this.editNewProductComponent.product.qty == undefined || 
      this.editNewProductComponent.product.qty.trim() == '') ? true : false);

  this.editNewProductComponent.vendor_require_error = 
    ((this.editNewProductComponent.product.vendor.vendorName == null || 
      this.editNewProductComponent.product.vendor.vendorName == undefined ||
      this.editNewProductComponent.product.vendor.vendorName.trim() == '') ? true : false);

  if(this.editNewProductComponent.product_desc_require_error || 
      this.editNewProductComponent.mfr_product_require_error || 
      this.editNewProductComponent.vendor_require_error ||
      this.editNewProductComponent.qty_require_error || 
      this.editNewProductComponent.qty_number_error ||
      this.editNewProductComponent.sellPrice_number_error){
    return;
  }

  this.products.forEach((product, index) => {
    if (product.seq == this.editNewProductComponent.product.seq) {
      product.description = this.editNewProductComponent.product.description;
      product.eta = this.editNewProductComponent.product.eta;
      product.mfrId = this.editNewProductComponent.product.mfrId;
      product.packSize = this.editNewProductComponent.product.packSize;
      product.salesUOM = this.editNewProductComponent.product.salesUOM;
      product.sellPrice = this.editNewProductComponent.product.sellPrice;
      product.qty = this.editNewProductComponent.product.qty;
      product.label = this.editNewProductComponent.product.label;
      product.prodType = this.editNewProductComponent.product.prodType;
      product.vendor.vendorName = this.editNewProductComponent.product.vendor.vendorName;
      product.vendor.vendorId = this.editNewProductComponent.product.vendor.vendorId;

      let tempDelete = this.editNewProductComponent.tempDelete;
      let req = this.editNewProductComponent.requisitionId;
      if(tempDelete.length > 0) {
        let event = this.actionDispatcherService.generateEvent(ActionEvents.PROD_ATTACHMENTS_MULTI_DELETE, {requisitionId: req, attachmentsList: tempDelete});
        this.actionDispatcherService.dispatch(event);

        tempDelete.forEach((item)=>{
          this.addNewProduct.attachmentsList = this.addNewProduct.attachmentsList.filter(function( obj ) {
            return obj.objectKey !== item.objectKey;
          });
          this.editNewProductComponent.attachmentsList = this.editNewProductComponent.attachmentsList.filter(function( obj ) {
            return obj.objectKey !== item.objectKey;
          });
        });
      }
      
      product.attachCount = this.editNewProductComponent.attachmentsList.length;

      //Update ShipTo Dist
      if(product.shipTodistribution.length == 1){
        product.shipTodistribution[0].qty = this.editNewProductComponent.product.qty;
        this.sumUpErr = false;
        product.shipTodistribution[0].sellPrice = this.editNewProductComponent.product.sellPrice;
      }else{
        product.shipTodistribution.forEach((shipTo, index)=>{
          //SOBI-1426
          //shipTo.qty = this.editNewProductComponent.product.qty;
          shipTo.qty = "0";
          this.sumUpErr = true;
          shipTo.sellPrice = this.editNewProductComponent.product.sellPrice;
        });
      }
    }    
  });
  
  //clean out logic here
    this.editNewProductComponent.date_selection_error = false;
    this.editNewProductComponent.product_desc_require_error = false;
    this.editNewProductComponent.vendor_require_error = false;
    this.editNewProductComponent.mfr_product_require_error = false;
    this.editNewProductComponent.qty_require_error = false;
    this.editNewProductComponent.qty_number_error = false;
    this.editNewProductComponent.zero_number_error = false;
    this.editNewProductComponent.sellPrice_number_error = false;
  //clean out ended
  this.editProductNewModal.close();
  
}

cancelEditNewProduct(){
    //clean out logic here
    this.editNewProductComponent.date_selection_error = false;
    this.editNewProductComponent.product_desc_require_error = false;
    this.editNewProductComponent.vendor_require_error = false;
    this.editNewProductComponent.mfr_product_require_error = false;
    this.editNewProductComponent.qty_require_error = false;
    this.editNewProductComponent.qty_number_error = false;
    this.editNewProductComponent.zero_number_error = false;
    this.editNewProductComponent.sellPrice_number_error = false;
    this.editNewProductComponent.softDeleteAttachments();
    //clean out ended
    this.editProductNewModal.close();
}

editExistingProduct(){

  //check duplicate first
  if(this.dataHasDuplicateValueforEdit(this.editExistingProductComponent.product)){
    this.editExistingProductComponent.duplicated_product_error = true;
    return;
  }
  else{
    this.editExistingProductComponent.qty_require_error = 
      ((this.editExistingProductComponent.product.qty == null || this.editExistingProductComponent.product.qty == undefined) ? true : false);
    if(this.editExistingProductComponent.qty_require_error){
      return;
    }

    //Validation
    this.editExistingProductComponent.checkSellPrice();
    this.editExistingProductComponent.checkHandlingPrice();
    this.editExistingProductComponent.checkNumberFormatforQty();
    this.editExistingProductComponent.checkKeyupRequire_qty();

    if(this.editExistingProductComponent.sellPrice_number_error || 
      this.editExistingProductComponent.handling_number_error || 
      this.editExistingProductComponent.qty_number_error ||
      this.editExistingProductComponent.qty_require_error ||
      this.editExistingProductComponent.zero_number_error){
        return;
    }
    //add validation for ordering multiples here
    if(this.editExistingProductComponent.product.convFctr != null && this.editExistingProductComponent.product.convFctr != undefined){
      if(Number(this.editExistingProductComponent.product.qty) % Number(this.editExistingProductComponent.product.convFctr) != 0){
        this.editExistingProductComponent.errMsg = 'Quantity must be entered in multiples of ' + this.editExistingProductComponent.product.convFctr;
        return;
      }
    }
}

  this.products.forEach((product, index) => {
    if (product.seq == this.editExistingProductComponent.product.seq) {
      product.description = this.editExistingProductComponent.product.description;
      product.productId = this.editExistingProductComponent.product.productId;
      product.eta = this.editExistingProductComponent.product.eta;
      product.mfrId = this.editExistingProductComponent.product.mfrId;
      product.packSize = this.editExistingProductComponent.product.packSize;
      product.salesUOM = this.editExistingProductComponent.product.salesUOM;
      product.sellPrice = this.editExistingProductComponent.product.sellPrice;
      product.qty = this.editExistingProductComponent.product.qty;
      product.label = this.editExistingProductComponent.product.label;
      product.prodType = this.editExistingProductComponent.product.prodType;
      product.vendor.vendorName = this.editExistingProductComponent.product.vendor.vendorName;
      product.vendor.vendorId = this.editExistingProductComponent.product.vendor.vendorId;
      product.handling = this.editExistingProductComponent.product.handling;
      //Update ShipTo Dist
      if(product.shipTodistribution.length == 1){
        product.shipTodistribution[0].qty = this.editExistingProductComponent.product.qty;
        this.sumUpErr = false;
        product.shipTodistribution[0].qty = '0';
        product.shipTodistribution[0].sellPrice = this.editExistingProductComponent.product.sellPrice;
      }else{
        product.shipTodistribution.forEach((shipTo, index)=>{
          //SOBI-1426
          //shipTo.qty = this.editExistingProductComponent.product.qty;
          shipTo.qty = "0";
          this.sumUpErr = true;
          shipTo.qty = '0';
          shipTo.sellPrice = this.editExistingProductComponent.product.sellPrice;
        });
      }
    }    
  });
  //clean out logic here
    this.editExistingProductComponent.date_selection_error = false;
    this.editExistingProductComponent.qty_require_error = false;
    this.editExistingProductComponent.qty_number_error = false;
    this.editExistingProductComponent.zero_number_error = false;
    this.editExistingProductComponent.sellPrice_number_error = false;
    this.editProductExistingModal.close();
}

cancelEditExistingProduct(){
  //clean out logic here
    this.editExistingProductComponent.date_selection_error = false;
    this.editExistingProductComponent.qty_require_error = false;
    this.editExistingProductComponent.qty_number_error = false;
    this.editExistingProductComponent.zero_number_error = false;
    this.editExistingProductComponent.sellPrice_number_error = false;
    this.editProductExistingModal.close();
}

renderShipToChange(data: any){
  //clean out the array firstly
  this.shipToArray = [];
  //then update the array
  //reset any error message
  this.sumUpErr = false;
  this.shipto_qty_number_error = false;
  this.shipto_sellPrice_number_error = false;
  data.forEach((element, index)=> {
    let shipToDistribution = new ShipToDistribution();
    shipToDistribution.id = element.id;
    shipToDistribution.departmentId = element.dept;
    shipToDistribution.customer = new Customer();
    shipToDistribution.customer.id = element.customer;
    shipToDistribution.customer.name = element.customerName;
    shipToDistribution.customer.address1 = element.address1;
    shipToDistribution.customer.address2 = element.address2;
    shipToDistribution.customer.zip = element.zip;
    shipToDistribution.customer.city = element.city;
    shipToDistribution.customer.state = element.state;
    shipToDistribution.customer.dept = element.department;
    shipToDistribution.departmentId = element.department;
    shipToDistribution.shipMethod = element.ship_method;
    shipToDistribution.customerPO = element.customerPo;
    shipToDistribution.specialInstructions = element.specialInstruct;
    this.shipToArray.push(shipToDistribution);
  });

  //update the product table
  this.products.forEach((product, index) => {
    product.shipTodistribution = this.shipToArray.map(x => Object.assign({}, x));

    //initialize the each shipTo component
    if(product.shipTodistribution.length == 1){
      product.shipTodistribution[0].qty = product.qty;
      this.sumUpErr = false;
      product.shipTodistribution[0].sellPrice = product.sellPrice;
      if(product.shipTodistribution[0].shipMethod == 'Next'){
        product.shipTodistribution[0].disableInput = true;
        product.shipTodistribution[0].customerPO = '';
        product.shipTodistribution[0].specialInstructions = '';
      }else{
        product.shipTodistribution[0].disableInput = false;
      }
    }else{
      product.shipTodistribution.forEach((shipTo, index) => {
        shipTo.qty = "0";
        this.sumUpErr = true;
        shipTo.sellPrice = product.sellPrice; 
        if(shipTo.shipMethod == 'Next'){
          shipTo.disableInput = true;
          shipTo.customerPO = '';
          shipTo.specialInstructions = '';
        }else{
          shipTo.disableInput = false;
        }
      });
    }
  });




}

//validate the sell price
checkSellPrice(shipTo: ShipToDistribution) {

  if(shipTo.sellPrice == "" || shipTo.sellPrice == null || shipTo.sellPrice == undefined) {
    shipTo.sellPrice_number_error = false;
    this.shipto_sellPrice_number_error = false;  
    return;   
  }
  
  if(this.validateQuotePrice(shipTo.sellPrice)) {
      shipTo.sellPrice_number_error = false;
      this.shipto_sellPrice_number_error = false;            
      //checks for whole integers (ex. 32) and converts to 32.00
      if(shipTo.sellPrice.indexOf('.') == -1 && !(shipTo.sellPrice.charAt(0) == '.')) 
        shipTo.sellPrice = shipTo.sellPrice.concat('.00');
      //checks for .xx and converts to 0.xx
      if(shipTo.sellPrice.charAt(0) == '.')
        shipTo.sellPrice = '0'.concat(shipTo.sellPrice);
  } else { 
      shipTo.sellPrice_number_error = true;
      this.shipto_sellPrice_number_error = true;  
  } 
}

validateQuotePrice(quote: string) : boolean {
  if(quote == null || quote == undefined || quote.trim() == "")
      return true;
  let QUOTE_REGEXP = /^\d{0,8}(\.\d{1,2})?$/
  return QUOTE_REGEXP.test(quote);
}

//Validate Number
validateNumber(data: string){
  let NUMBER_REGEXP = /^[0-9]{1,5}$/
  return NUMBER_REGEXP.test(data);
}

//validate the qty
checkQty(shipTo: ShipToDistribution, product: Product, products: Product[]){

  if(this.validateNumber(shipTo.qty)) {
    shipTo.qty_number_error = false;
    this.shipto_qty_number_error = false;
  } else { 
    shipTo.qty_number_error = true;
    this.shipto_qty_number_error = true;
    this.sumUpErr = false;
    return;
  }

  //we need to check every shipto
  this.shipto_qty_number_error = false;
  products.forEach((item, index)=>{
    item.shipTodistribution.forEach((shipTo, index) => {
      if(!this.validateNumber(shipTo.qty)) {
        shipTo.qty_number_error = true;
        this.shipto_qty_number_error = true;
        this.sumUpErr = false;
      }
    });
  });

  if(!this.shipto_qty_number_error){
    this.sumUpErr = false;
    products.forEach((item, index)=>{
      let totalQty: number = 0;
      item.shipTodistribution.forEach((shipTo, index) => {
        if(shipTo.qty != null && shipTo.qty != undefined && shipTo.qty.trim() != ""){
          totalQty += parseInt(shipTo.qty);  
        }
      });
      if(totalQty != parseInt(item.qty)){
        //TODO: intialize the sumup error
        this.sumUpErr = true;
        shipTo.qty_number_error = false;
      }
    });
  }
}

renderDeptChangeSuccess(deptId: string){

  this.products.forEach((product, index) => {
    product.shipTodistribution[0].departmentId = deptId;
  });

}

checkCountOnProduct() {
  let countErrors = [];
  this.products.forEach((p) => {
    // q.qty
    let qty = 0;
    p.shipTodistribution.forEach((shipTo) => {
      qty += parseInt(shipTo.qty);
    });
    if (qty !== parseInt(p.qty)) {
      countErrors.push(`Allocated Quantities are out of balance for product id ${p.productId}`);
    }
  });
  return countErrors;
}

renderShipmentChangeSuccess(data: any){
  this.defaultShipMethod = data.shipMethod;
  this.defaultCustomerPO = data.customerPO;
  this.defaultSpecInstructions = data.specialInstruct;
  this.products.forEach((product, index) => {
    product.shipTodistribution[0].shipMethod = data.shipMethod;
    if(data.shipMethod == 'Separate'){
      product.shipTodistribution[0].disableInput = false;
      product.shipTodistribution[0].customerPO = data.customerPO;
      product.shipTodistribution[0].specialInstructions = data.specialInstruct;
    }else{
      product.shipTodistribution[0].disableInput = true;
      product.shipTodistribution[0].customerPO = '';
      product.shipTodistribution[0].specialInstructions = '';
    }
  });
}

autogrow(){
  let textArea = document.getElementById("area");       
  textArea.style.overflow = 'hidden';
  textArea.style.height = '50px';
  textArea.style.height = textArea.scrollHeight + 'px';
}

checkSpecialInstruction(shipTo: ShipToDistribution){
    shipTo.specialInstructions = shipTo.specialInstructions.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
}

openProductAttachment(requisitionId, attachmentKey){
  this.productAttachmentComponent.attachmentsList = [];
  let event = this.actionDispatcherService.generateEvent(ActionEvents.PROD_ATTACHMENT_DETAILS, {requisitionId: this.addNewProduct.requisitionId, attachmentKey:attachmentKey});
  this.actionDispatcherService.dispatch(event);
  this.productAttachmentModal.open();
}

downloadAll(){
  let requisitionId = this.addNewProduct.requisitionId;
  let event = this.actionDispatcherService.generateEvent(ActionEvents.PROD_ATTACHMENTS_MULTI_DOWNLOAD, {requisitionId: this.requisitionId, attachmentsList: this.attachmentsList, attachmentKey: this.globalAttachmentKey });
  this.actionDispatcherService.dispatch(event);
}

prodMultiDownloadSuccess(){
  console.log("Multiple download success");
}

prodMultiDownloadFail(){
  console.log("Multiple Download fail");
}

cancelProductAttchment(){
  this.productAttachmentModal.close();
}

renderAttachmentDetails(data) {
  console.log("Rendering Attachment Details: " + data[0].fileName);
  this.attachmentsList = data;
}

prodMultiDeleteSuccess(){
  console.log("Product deleted successfully");
}

prodMultiDeleteFail(){
  console.log("Product is not deleted");
}

getDateFormat(date: Date) {
  let d = '';
  d += date.getFullYear();
  d += '-' + (((date.getMonth() + 1) <= 9) ? '0' + (date.getMonth() + 1) : (date.getMonth() + 1));
  d += '-' + date.getDate();
  d += ' ' + ((date.getHours() <= 9) ? '0' + date.getHours() : date.getHours());
  d += ':' + ((date.getMinutes() <= 9) ? '0' + date.getMinutes() : date.getMinutes());
  d += ':' + ((date.getSeconds() <= 9) ? '0' + date.getSeconds() : date.getSeconds());
  return d;
}

}