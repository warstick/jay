import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload-product',
  templateUrl: './upload-product.component.html',
  styleUrls: ['./upload-product.component.css']
})
export class UploadProductComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
