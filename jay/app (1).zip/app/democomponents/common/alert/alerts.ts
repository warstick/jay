export const ALERTS = {
    'success': {
        'rolesValidated': 'Validation Successful. All Roles are active.',
        'rolesSaved': 'Save Successful. All Roles are active.',
        'requisitionApproval': 'Requisition Approved Successfully.',
        'requisitionReturn': 'Requisition Returned Successfully.'
    },
    'error': {
        'divisionDownloadFailed': 'An error occurrred downloading the divisions',
        'levelOneRequired': 'Level 1 is required.',
        'invalidNetworkId': 'Please enter a valid user.',
        'genericValidationError': 'Validation Unsuccessful. Please try again.',
        'renderMarketFail': 'An error occurred downloading the market roles',
        'duplicateNetworkId': '"Network ID" is already added',
        'reqDetailsNotFound': 'Could not get the requistion details',
        'missingReqId': 'Invalid request',
        'noRoleSelected': 'Please select a role',
        'productMarkedReturn': 'One or more products are checked to be returned to requestor.  Please uncheck the return product checkbox to approve the requisition.',
        'noCommentsAddedToProduct': 'Please enter a comment for each product you wish to return to the requestor.',
        'noProductMarkedReturn': 'Please select a product to return.',
        'requisitionApproval': 'Failed to complete task.',
        'requisitionReturn': 'Failed to complete task.'
    }

};
