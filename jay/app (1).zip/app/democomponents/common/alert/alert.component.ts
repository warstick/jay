import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { ALERTS } from './alerts';

@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.css']
})
export class AlertComponent implements OnInit, OnChanges{

  @Input() alertSettings: any[];

  message: string;
  alert: any[];

  constructor() {
  }

  ngOnInit() {
    this.alert = this.alertSettings;
    this.message = ALERTS[this.alert[0].alertType][this.alert[0].alertMessage];
  }

  ngDoCheck() {

  }

  ngOnChanges(changes: SimpleChanges): void {

  }
}
