import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-ship-to-dist',
  templateUrl: './product-ship-to-dist.component.html',
  styleUrls: ['./product-ship-to-dist.component.css']
})
export class ProductShipToDistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
