import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductShipToDistComponent } from './product-ship-to-dist.component';

describe('ProductShipToDistComponent', () => {
  let component: ProductShipToDistComponent;
  let fixture: ComponentFixture<ProductShipToDistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductShipToDistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductShipToDistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
