import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-ship-to',
  templateUrl: './add-ship-to.component.html',
  styleUrls: ['./add-ship-to.component.css']
})
export class AddShipToComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
