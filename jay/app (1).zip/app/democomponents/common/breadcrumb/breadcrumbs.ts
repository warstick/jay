export const BREADCRUMBS = {
    'home': {
        'heading': 'SODS',
        'links': [
            {
                'href': '/taskInbox',
                'name': 'Home',
                'active': true
            }
        ]
    },
    'create-requisition': {
        'heading': 'Create Requisition',
        'links': [
            {
                'href': '/sodsnew',
                'name': 'Create Requisition',
                'active': true
            }
        ]
    },
    'market-role-manager': {
        'heading': 'Market Role Manager',
        'links': [
            {
                'href': '/marketrolemanager',
                'name': 'Market Role Manager',
                'active': true
            }
        ]
    },
    'approver':{
        'heading': 'Approver Screen',
        'links': [
            {
                'href': '/approver',
                'name': 'Approver',
                'active': true
            }
        ]
    }
};
