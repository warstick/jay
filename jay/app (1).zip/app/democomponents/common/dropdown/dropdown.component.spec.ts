import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DropdownComponent } from './dropdown.component';

fdescribe('DropdownComponent', () => {
  let component: DropdownComponent;
  let fixture: ComponentFixture<DropdownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DropdownComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display options', () => {
    let element = fixture.nativeElement;
    component.selectedOption = 'test';
    fixture.detectChanges();
    expect(element.querySelector('button').innerHTML).toBe('test');
  });

  it('should select the correct option and emit the correct behavior', ()=>{
    //init value
    let element = fixture.nativeElement;
    spyOn(component.selectionDone, 'emit');
    
    //execute
    component.select('test');
    fixture.detectChanges();

    //validate
    //1. validate two variables
    expect(component.selectedOption).toBe('test');
    expect(component.isVisible).toBe(true);
    //2. validate the event emitter
    expect(component.selectionDone.emit).toHaveBeenCalledWith('test');
    //3. valiate the HTML component
    expect(element.querySelector('button').innerHTML).toBe('test');
  });

  it('should have the correct behavior for toggling dropdown', ()=>{
    //init
    component.isVisible = false;
    
    //execute
    component.toggleDropDown();
    fixture.detectChanges();

    //validate
    expect(component.isVisible).toBe(true);
  });

  it('should have correct behavior for keyup event', ()=>{
    //init
    component.isVisible = true;
    const event = new KeyboardEvent("keyup",{
      code: 'Tab'
    });
    window.dispatchEvent(event);
    
    //execute
    component.handleKeyup(event);

    //validate
    expect(event.code).toBe('Tab');
    expect(component.isVisible).toBe(false);
  });

  it('should have correct behavior for click event', ()=>{
       //init
       let clickEvent = document.createEvent('MouseEvents');
       clickEvent.initMouseEvent("click", true, true, window, 0, 0, 0, 80, 20, false, false, false, false, 0, null);
       let element = fixture.nativeElement;
       
       
       //execute
       component.handleClick(clickEvent);
   
       //validate
       expect(component.isVisible).toBe(false);
     });

});
