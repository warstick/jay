import { SharedModule } from './../../../shared/shared.module';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CustomerDetailsComponent } from './customer-details.component';
import { FormsModule } from '@angular/forms';
import { EditCustomerComponent } from './edit-customer.component'

fdescribe('CustomerDetailsComponent', () => {
  let component: CustomerDetailsComponent;
  let fixture: ComponentFixture<CustomerDetailsComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ],
      imports: [ SharedModule] 
    })
    .compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerDetailsComponent);
    component = fixture.componentInstance;
    component.actionDispatcherService.dispatch = (ev: any) => {};
    fixture.detectChanges();
  });
  it('should create', () => {
        fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('should selectedDept', () => {
    component.onDeptSelection('FOOD');
    fixture.detectChanges();
    expect(component.selectedDept).toEqual('FOOD');
  });

  it('should onShipmentSelection', () => {
    // selected ship with food
    component.onShipmentSelection('FOOD');
    expect(component.selectedShip).toEqual('FOOD');
    expect(component.shipElementsHidden).toBeFalsy();

    // selected ship with Next
    component.onShipmentSelection('Next');
    expect(component.selectedShip).toEqual('Next');
    expect(component.shipElementsHidden).toBeTruthy();
  });
  
  it('should onETASelection', () => {

    let value;
    // Select Date
    component.onETASelection('Select Date');
    expect(component.selectedETA).toEqual('Select Date');
    expect(component.value).toBe(null);

    // ASAP No Maximum Date
    component.onETASelection('ASAP No Maximum');
    expect(component.selectedETA).toEqual('ASAP No Maximum');
    expect(component.value).toBe(null);

    // ASAP 3 Week Max Date
    component.onETASelection('ASAP 3 Week Max');
    expect(component.selectedETA).toEqual('ASAP 3 Week Max');
    value =new Date();
    value.setDate(value.getDate() + 21);
    expect(component.value.getDate()).toBe(value.getDate());

    // ASAP 4 Week Max Date
    component.onETASelection('ASAP 4 Week Max');
    expect(component.selectedETA).toEqual('ASAP 4 Week Max');
    value =new Date();
    value.setDate(value.getDate() + 28);
    expect(component.value.getDate()).toBe(value.getDate());

    // Custom Date
    component.onETASelection('Custom Date');
    expect(component.selectedETA).toEqual('Custom Date');
    expect(component.value.getDate()).toBe(value.getDate());
    
  });

  it('should onDateSelectionDone', () => {
    // onDateSelectionDone
    component.onDateSelectionDone({});
  });

  it('should onErrorHandler', () => {
    // onErrorHandler
    component.onErrorHandler('error');
    expect(component.date_selection_error).toBeTruthy();

    // onErrorHandler
    component.onErrorHandler('error11');
    expect(component.date_selection_error).toBeFalsy();
  });

  it('should checkQuote', () => {
    // checkquote
    component.quotePrice = '';
    component.checkQuote();
    expect(component.quoteValid).toBeTruthy();

    // checkquote
    component.quotePrice = ' ';
    component.checkQuote();
    expect(component.quoteValid).toBeTruthy();

    // checkquote
    component.quotePrice = '.0';
    component.checkQuote();
    expect(component.quoteValid).toBeTruthy();

    // checkquote
    component.quotePrice = '0';
    component.checkQuote();
    expect(component.quoteValid).toBeTruthy();

    // checkquote
    component.quotePrice = '11111111.22';
    component.checkQuote();
    expect(component.quoteValid).toBeTruthy();

    // checkquote
    component.quotePrice = 'adasds.22';
    component.checkQuote();
    expect(component.quoteValid).toBeFalsy();
  });

  it('should checkdate', () => {
    //valid date
    component.date = '10-07-1991';
    component.checkDate()
    expect(component.dateValid).toBe(true);

    //invalid date
    component.date = 'dsdad';
    component.checkDate()
    expect(component.dateValid).toBe(false);

    component.date = '';
    component.checkDate()
    expect(component.dateValid).toBe(true);

  });

  it('should Misc', () => {

    component.updateModal.close = () => {};
    //open Update Modal
    component.open();
    //close update Modal
    component.close();
    //cancel Operation
    component.cancel();

    //check edit customer values
    expect(component.editCustomer.error).toBe(false);
    expect(component.editCustomer.id).toBe("");

    //component update
    component.update();
    expect(component.editCustomer.error).toBe(false);

  });
});