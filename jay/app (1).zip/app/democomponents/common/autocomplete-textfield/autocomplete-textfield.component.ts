import { Component, OnInit, Input, Output, EventEmitter, HostListener, ElementRef, ViewChild, PipeTransform, Pipe } from '@angular/core';

@Component({
  selector: 'app-autocomplete-textfield',
  templateUrl: './autocomplete-textfield.component.html',
  styleUrls: ['./autocomplete-textfield.component.css']
})
export class AutocompleteTextfieldComponent implements OnInit {
  inputValue: string;
  @ViewChild('dropdown', { read: ElementRef }) public dropdown: ElementRef;
  @Input() data: any[];
  @Input() valid = true;

  @Input() set value(value: string) {
    this.inputValue = value;
  }
  @Output('valueChanged')
  valueChanged: EventEmitter<any> = new EventEmitter<any>();
  isVisible = false;
  list: any[] = [];
  filteredList: any[] = [];
  selectedValue: string;
  keyLocation = 0;
  isValid = true;

  @HostListener('document: click', ['$event.target'])
  onClick(target: HTMLElement) {
    let parentFound = false;
    while (target !== null && !parentFound) {
      if (target === this.element.nativeElement) {
        parentFound = true;
      }
      target = target.parentElement;
    }
    if (!parentFound) {
      this.isVisible = false;
    }
  }

  constructor(private element: ElementRef) { }

  ngOnInit() {
    this.data = this.data.sort();
    this.list = this.data;
    this.filteredList = [];
  }

  toggleDropDown($event: Event) {
    this.isVisible = !this.isVisible;
    this.filter();
  }

  onTxtFieldBlur(selectedValue: any) {
    this.inputValue = selectedValue;
    this.valueChanged.emit(this.inputValue);
  }

  setSelectedValue(selectedValue: any) {
    console.log(selectedValue);
    this.inputValue = selectedValue;
    this.isVisible = false;
    this.valueChanged.emit(this.inputValue);
  }

  filter() {
    this.filteredList = [];
    if (this.inputValue) {
      // this.filteredList = this.data.filter(function (el) {
      //   return el.toLowerCase().startsWith(this.inputValue.toLowerCase()) > -1;
      // }.bind(this));
      this.filteredList = this.list.filter((item) => item.startsWith(this.inputValue));

    } else {
      this.filteredList = this.list;
    }

  }
  keyDown(event) {
    //this.inputValue = event.target.value;
    this.filter();
    this.isVisible = true;
    //this.keyLocation = 0;
    //this.selectedValue = this.filteredList[0];
    switch (event.keyCode) {
      case 38: // this is the ascii of arrow up
        if (this.keyLocation > 0) {
          this.keyLocation--;
          this.selectedValue = this.filteredList[this.keyLocation];
          this.dropdown.nativeElement.scrollTop -= 37;
        }
        break;
      case 40: // this is the ascii of arrow down
        // alert(this.inputValue);
        if (this.keyLocation < this.filteredList.length - 1) {
          this.keyLocation++;
          this.selectedValue = this.filteredList[this.keyLocation];
          this.dropdown.nativeElement.scrollTop += 37;
        }
        break;
      case 13: // this is the ascii of enter
        this.isVisible = false;
        this.inputValue = this.selectedValue;
        this.keyLocation = 0;
        this.filteredList = [];
        break;
      case 27: // this is the ascii of escape
        this.isVisible = false;
        this.keyLocation = 0;
    }
  }

}

@Pipe({name: 'filterPipe'})
export class FilterPipe implements PipeTransform {
  transform(value: any, search: string):any {
    if (!search) {
      return value;
    }
    const solution = value.filter(v => {
      if(!v) {
        return;
      } else {
        return v.toLowerCase().indexOf(search.toLowerCase()) >= 0;
      }
    });
    return solution;
  }

}
