import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproverBuyerProductComponent } from './approver-buyer-product.component';

describe('ApproverBuyerProductComponent', () => {
  let component: ApproverBuyerProductComponent;
  let fixture: ComponentFixture<ApproverBuyerProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApproverBuyerProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproverBuyerProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
