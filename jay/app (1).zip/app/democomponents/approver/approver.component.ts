import { ApproverProductAttachmentProdInfoComponent } from './approver-product-attachment-prod-info/approver-product-attachment-prod-info.component';
import { ApproverProductComponent } from './approver-product/approver-product.component';
import { ApproverCategoryManagerProductComponent } from './approver-category-manager-product/approver-category-manager-product.component';
import { ViewAttachmentsComponent } from './../sodstaskinbox/viewattachments.component';
import { Attachment } from './../../model/attachment';
import { ApproverAttachmentComponent } from './approver-attachment/approver-attachment.component';
import { Component, OnInit, OnDestroy, ViewChild, Output, EventEmitter } from '@angular/core';
import { BREADCRUMBS } from 'app/democomponents/common/breadcrumb/breadcrumbs';
import { ReqDetails, TaskInboxProduct } from '../../model/submitRequisition';
import { BaseComponent } from '../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ModelChangeUpdateEvents, ActionEvents } from '../../events/action-events';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ALERTS } from '../common/alert/alerts';
import { ApproverRequisitionHeaderComponent } from './approver-requisition-header/approver-requisition-header.component';
import { DivisionsService } from '../../service/divisions.service';
import { Division } from '../../model/division';
import { Modal } from 'ngx-modal';
import { ApproverBuyerProductComponent } from "app/democomponents/approver/approver-buyer-product/approver-buyer-product.component";
import { ApproverBuyerPoProductComponent } from "app/democomponents/approver/approver-buyer-po-product/approver-buyer-po-product.component";

@Component({
  selector: 'app-approver',
  templateUrl: './approver.component.html',
  styleUrls: ['./approver.component.css']
})
export class ApproverComponent extends BaseComponent implements OnInit, OnDestroy {
  @ViewChild('reqDetailsHeader') reqDetailsHeader: ApproverRequisitionHeaderComponent;
  @ViewChild('warningError') warningErrorModal: Modal;

  // For Loading Indicator
  public loading = false;

  public breadcrumbs = BREADCRUMBS['approver'];

  // For Alerts
  alertSettings: any[] = [];
  alertMessage: string;
  showAlert = false;

  // For Requistion Details
  public taskId = '';
  public reqDetails: ReqDetails = new ReqDetails();
  public reqDetailsArray: any[] = new Array<any>();
  public collapsed: boolean[] = new Array<boolean>();
  public allCollapsed = false;
  public allNewReturned = false;
  public allOutOfMarketReturned = false;
  public market: string;
  public reqStatus: string = 'Pending Product/Vendor Setup';
  public buttonsDisabled = false;
  public taskName: string = '';
  private productHasNewComment: boolean[] = new Array<boolean>();
  public invalidProducts: number[] = new Array<number>();
  public reqId = '';

  // For New Products Section
  public productsNew: TaskInboxProduct[] = new Array<TaskInboxProduct>();

  // For Products Not Attached Section
  public productsNotAttached: TaskInboxProduct[] = new Array<TaskInboxProduct>();

  // For all Products
  public taskInboxProducts: TaskInboxProduct[] = new Array<TaskInboxProduct>();

  @ViewChild('ApproverAttachment') approverAttachment: ApproverAttachmentComponent;
  @ViewChild('CategoryManagerProduct') categoryManagerProduct: ApproverCategoryManagerProductComponent;
  @ViewChild('NewApproverProduct') newApproverProduct: ApproverProductComponent;
  @ViewChild('ProductAttachmentProdInfo') productAttachmentProdInfo: ApproverProductAttachmentProdInfoComponent;
  @ViewChild('ProductBuyerProduct') productBuyerProduct: ApproverBuyerProductComponent;
  @ViewChild('ProductBuyerProductPO') productBuyerProductPO: ApproverBuyerPoProductComponent;

  constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService, private activatedRoute: ActivatedRoute, private divisionsService: DivisionsService) {
    super(stateRepresentationRendererService);
    const mapping: any = [];
    //  For loading the requistion details
    mapping[ModelChangeUpdateEvents.GET_REQ_DETAILS_FOR_APPROVALS_SUCCESS] = (data: any) => {this.renderReqDetailsForApprovalsSuccess(data);};
    mapping[ModelChangeUpdateEvents.GET_REQ_DETAILS_FOR_APPROVALS_FAIL] = (data: any) => {this.renderReqDetailsForApprovalsFail(data);};
    mapping[ModelChangeUpdateEvents.DIVISIONS_FOR_ROLE_SEARCH_SUCCESS] = (data: any) => {this.renderDivisionsForRoleSearch(data);};
    mapping[ModelChangeUpdateEvents.DIVISIONS_FOR_ROLE_SEARCH_FAIL] = (data: any) => {this.renderDivisionsForRoleSearchFail(data);};
    mapping[ModelChangeUpdateEvents.COMPLETE_TASK_SUCCESS] = (data: any) => {this.completeTaskSuccess(data);};
    mapping[ModelChangeUpdateEvents.COMPLETE_TASK_FAIL] = (data: any) => {this.completeTaskFail(data);};
    mapping[ModelChangeUpdateEvents.REQ_ATTACH_DETAILS_SUCCESS] = (data: string[]) => {this.passReqIdToComponents();}
    mapping[ModelChangeUpdateEvents.REQ_ATTACH_DETAILS_FAIL] = () => {this.passReqIdToComponents()}

    mapping[ModelChangeUpdateEvents.ACCEPT_TASK_SUCCESS] = (data: any) => {};
    mapping[ModelChangeUpdateEvents.ACCEPT_TASK_FAIL] = (data: any) => {};
    mapping[ModelChangeUpdateEvents.RELEASE_TASK_SUCCESS] = (data: string[]) => {}
    mapping[ModelChangeUpdateEvents.RELEASE_TASK_FAIL] = () => {}

    super.registerStateChangeEvents(mapping);
  }

  ngOnInit() {
    this.initData();
  }

  initData() {
    // Extract the taskId from the url query param
    this.taskId = this.activatedRoute.snapshot.queryParams['taskId'].trim() || '';
    if (this.taskId) {
      // Get the Requistion Details For Approvals
      const getReqDetails = this.actionDispatcherService.generateEvent(ActionEvents.GET_REQ_DETAILS_FOR_APPROVALS, { 'taskId': this.taskId });
      this.actionDispatcherService.dispatch(getReqDetails);
    }
    // Set the collapsible panels
    this.collapsed = [false, true, true, true, true];
  }

  renderReqDetailsForApprovalsSuccess(response: ReqDetails) {
    this.reqDetails = response;
    this.reqDetailsArray.push(this.reqDetails);
    this.productsNotAttached = this.getProductsNotAttached(this.reqDetails.products);
    this.productsNew = this.getNewProducts(this.reqDetails.products);
    this.taskInboxProducts = this.reqDetails.products;
    this.reqStatus = this.reqDetails.requisition.status;
    this.reqId = this.reqDetails.requisition.requisitionNumber
    //Make call to get attachment details, on success populate the list in the attachments component
    let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENT_DETAILS, {requisitionId: this.reqId});
    this.actionDispatcherService.dispatch(event);
    // Set up to track new comments
    this.reqDetails.products.forEach((product) => {
      this.productHasNewComment.push(false);
    });

    this.getDivisions();
  }

  passReqIdToComponents() {
    let reqDet = JSON.stringify(this.reqDetails);
    let req = JSON.stringify(JSON.parse(reqDet).requisition);
    let reqNbr = JSON.parse(req).requisitionNumber;
    if(this.approverAttachment != undefined) {
      this.approverAttachment.requisitionId = reqNbr;
    }
    if(this.categoryManagerProduct != undefined) {
      this.categoryManagerProduct.reqNbr = reqNbr;
    }
    if(this.newApproverProduct != undefined) {
      this.newApproverProduct.reqNbr = reqNbr;
    }
    if(this.productAttachmentProdInfo != undefined) {
      this.productAttachmentProdInfo.reqNbr = reqNbr;
    }
    if(this.productBuyerProduct != undefined){
      this.productBuyerProduct.reqNbr = reqNbr;
    }
    if(this.productBuyerProductPO != undefined){
      this.productBuyerProductPO.reqNbr = reqNbr;
    }
  }

  renderReqDetailsForApprovalsFail(response) {
    this.showAlertMessage('error', 'reqDetailsNotFound');
  }

  getNewProducts(products: TaskInboxProduct[]): TaskInboxProduct[] {
    const productsNew = products.filter((product) => {
      return product.new === 'true';
    });
    return productsNew;
  }

  getProductsNotAttached(products: TaskInboxProduct[]): TaskInboxProduct[] {
    const productsNotAttached = products.filter((product) => {
      return product.attached === 'false';
    });
    return productsNotAttached;
  }

  expandAll() {
    this.allCollapsed = false;
    this.collapsed = [false, false, false, false, false];
  }

  collapseAll() {
    this.allCollapsed = true;
    this.collapsed = [true, true, true, true, true];
  }

  toggleSection(index: number) {
    this.collapsed[index] = !this.collapsed[index];
  }

  getDivisions() {
    // Make an api call to get the division codes for later screens
    const getDivisionsEvent = this.actionDispatcherService.generateEvent(ActionEvents.GET_DIVISIONS_FOR_ROLE_SEARCH, { 'data': '' });
    this.actionDispatcherService.dispatch(getDivisionsEvent);
  }

  renderDivisionsForRoleSearch(divResponse) {
    this.divisionsService.setDivisions(divResponse);
    let markets: Division[] = this.findInArray(this.divisionsService.getDivisions(), 'divisionNumber', Number(this.reqDetails.requisition.division));
    this.market = markets[0].divisionName + ' (' + markets[0].divisionCode + ', ' + markets[0].divisionNumber + ')';
  }

  renderDivisionsForRoleSearchFail(response) {
    this.showAlertMessage('error', 'divisionDownloadFailed');
  }

  approveRequisition() {
    let request = {};
    // check to make sure there are no products to return
    debugger
    if (this.isProductsToReturn()) {
      this.showAlertMessage('error', 'productMarkedReturn');
    } else {
      request = {
        'taskId': this.taskId,
        'taskName': this.reqDetails.taskName,
        'taskAction': '',
        'completedByID': localStorage.username,
        'completedByName': JSON.parse(JSON.parse(localStorage.getItem('user'))._body).displayName,
        'appId': 'SODS',
        'status': 'Active',
        'requisition': this.reqDetails.requisition,
        'requestor': this.reqDetails.requestor,
        'territoryManager': this.reqDetails.territoryManager,
        'customers': this.reqDetails.customers,
        'products': this.reqDetails.products,
        'auditLogs': this.reqDetails.auditLogs
      };
      // Make an api call to accept the requisition
      const completeTaskEvent = this.actionDispatcherService.generateEvent(ActionEvents.COMPLETE_TASK, { 'body': request, 'taskType': 'approve' });
      this.actionDispatcherService.dispatch(completeTaskEvent);
    }
  }

  isProductsToReturn() {
    let productsToReturn = this.getProductsToReturn();
    return productsToReturn.length > 0;
  }

  getProductsToReturn() {
    return this.findInArray(this.reqDetails.products, 'returned', true);
  }

  validateApprove() {
    const data ={'taskId': this.taskId, "networkId": "SODSUS01"};
    const completeTaskEvent = this.actionDispatcherService.generateEvent(ActionEvents.ACCEPT_TASK_REQ, { 'body': data });
    this.actionDispatcherService.dispatch(completeTaskEvent);
  }

  releaseApprove() {
    const data ={'taskId': this.taskId};
    const completeTaskEvent = this.actionDispatcherService.generateEvent(ActionEvents.RELEASE_TASK_REQ, { 'body': data });
    this.actionDispatcherService.dispatch(completeTaskEvent);
  }

  completeTaskSuccess(data) {
    if (data.taskType === 'approve') {
      this.showAlertMessage('success', 'requisitionApproval');
    } else {
      this.showAlertMessage('success', 'requisitionReturn');
    }

    this.buttonsDisabled = true;
  }

  completeTaskFail(data) {
    if (data.taskType === 'approve') {
      this.showAlertMessage('error', 'requisitionApproval');
    } else {
      this.showAlertMessage('error', 'requisitionReturn');
    }
  }

  returnRequisition() {
    // close confirm modal
    this.warningErrorModal.close();
    let request = {};
    // check to make sure there are products to return
    if (!this.isProductsToReturn()) {
      // show warning message
      this.showAlertMessage('error', 'noProductMarkedReturn');
    } else if (!this.productsHaveComments()) {
      // Tell user that they have to add comment
      this.showAlertMessage('error', 'noCommentsAddedToProduct');
    } else {
      // format request
      request = {
        'taskId': this.taskId,
        'taskName': this.reqDetails.taskName,
        'taskAction': 'Return',
        'completedByID': localStorage.username,
        'completedByName': JSON.parse(JSON.parse(localStorage.getItem('user'))._body).displayName,
        'appId': 'SODS',
        'status': 'Active',
        'requisition': this.reqDetails.requisition,
        'requestor': this.reqDetails.requestor,
        'territoryManager': this.reqDetails.territoryManager,
        'customers': this.reqDetails.customers,
        'products': this.reqDetails.products,
        'auditLogs': this.reqDetails.auditLogs
      };
      // Make an api call to return the requisition
      const completeTaskEvent = this.actionDispatcherService.generateEvent(ActionEvents.COMPLETE_TASK, { 'body': request, 'taskType': 'return' });
      this.actionDispatcherService.dispatch(completeTaskEvent);
    }

  }

  productsHaveComments(): boolean {
    let totalComments = 0;
    this.reqDetails.products.forEach((product, i) => {
      if (product.returned && this.productHasNewComment[i]) {
        totalComments++;
      } else if (product.returned && !this.productHasNewComment[i]) {
          this.invalidProducts.push(product.seq);
      }
    });
    return totalComments === this.getProductsToReturn().length;
  }

  addComment(event): void {
    console.log("ADD COMMENT FUNCTION CALLED:  ");
    const seq = event.product.seq;
    const productIndex = this.reqDetails.products.findIndex(x => x.seq === seq);
    this.productHasNewComment[productIndex] = true;
    let index = this.invalidProducts.findIndex(x => x === seq);
    this.invalidProducts.splice(index, 1);

    if (this.invalidProducts.length > 0) {
      this.showAlert = false;
    }
  }

  toggleReturnProduct(event) {
    const product: TaskInboxProduct = event.product;
    const seq = product.seq;
    const productIndex = this.reqDetails.products.findIndex(x => x.seq === seq);
    this.reqDetails.products[productIndex].returned = !this.reqDetails.products[productIndex].returned;
    this.productsNew = this.getNewProducts(this.reqDetails.products);
    this.productsNotAttached = this.getProductsNotAttached(this.reqDetails.products);
    this.allNewReturned = this.isAllReturned(this.productsNew);
    this.allOutOfMarketReturned = this.isAllReturned(this.productsNotAttached);

    // Remove flag for invalid product if the return box is unchecked
    if (!this.reqDetails.products[productIndex].returned) {
      const index = this.invalidProducts.findIndex(x => x === seq);
      this.invalidProducts.splice(index, 1);
      // remove alert if there are no more invalid products
      if (this.invalidProducts.length === 0) {
        this.showAlert = false;
      }
    }
  }

  toggleAllReturnNewProducts(event) {
    let returned = event.returned;
    this.reqDetails.products.forEach((product) => {
      if (product.new === 'true') {
        product.returned = returned;
      }
    });
    this.allNewReturned = this.isAllReturned(this.productsNew);
  }

  toggleAllNonMarketProducts(event) {
    let returned = event.returned;
    this.reqDetails.products.forEach((product) => {
      if (product.attached === 'false') {
        product.returned = returned;
      }
    });
    this.allOutOfMarketReturned = this.isAllReturned(this.productsNotAttached);
  }

  isAllReturned(products: TaskInboxProduct[]) {
    let totalReturned = 0;
    products.forEach((e) => {
      console.log(e.returned);
      if (e.returned) {
        totalReturned++;
      }
    });

    return (totalReturned === products.length && products.length > 0);
  }

  showAlertMessage(alertType: string, alertText: string) {
    this.alertSettings = [];
    this.alertMessage = ALERTS[alertType][alertText];
    const alert = { 'alertType': alertType, 'alertMessage': this.alertMessage };
    this.alertSettings.push(alert);
    this.showAlert = true;
    this.loading = false;
    this.goTo('top');
  }

  goTo(location: string): void {
    window.location.hash = '';
    window.location.hash = location;
  }

  updateProductNumber(product): string {
    let productIndex = this.findIndex(this.reqDetails.products, 'manufacturerId', product.manufacturerId);
    this.reqDetails.products[productIndex].productId = product.productId;
    return this.reqDetails.products[productIndex].productId;
  }

  findInArray(array: any, property: string, value: any) {
    return array.filter((obj) => {
      return obj[property] === value;
    });
  }

  findIndex(array, property, value) {
    return array.findIndex(x => x[property] === value);
  }

  // start of modal functions

  openWarningModal() {
    this.warningErrorModal.open();
  }

  closeWarning() {
    this.warningErrorModal.close();
  }

  ngOnDestroy() {
    super.ngOnDestroy();
  }

  //determine which approver screen should go to
  checkTaskNames(taskName: string){
    if((taskName == null) || (taskName) == undefined){
      return 'invalid';
    }
    if(taskName.startsWith('Approve Requisition')){
      return 'approver';
    }
    if(taskName.startsWith('Approve New Item')){
      return 'NIA'; 
    }
    if(taskName.startsWith('Approve and Setup Products')){
      return 'catMgr';
    }
    if(taskName.startsWith('Attach Products and Check Product Status')){
      return 'replSpcl';
    }
    if(taskName.startsWith('Enter Cost')){
      return 'buyer1';
    }
    if(taskName.startsWith('Enter PO Creation Method')){
      return 'buyer2';
    }
    if(taskName.startsWith('Analyze Credit')){
      return 'creditAnalyst';
    }
    if(taskName.startsWith('Enter PO Number')){
      return 'buyerPO';
    }
    if(taskName.startsWith('Recalled') || taskName.startsWith('Draft') || taskName.startsWith('Returned')){
      return 'draft';
    }
    return 'invalid';
  }

}
