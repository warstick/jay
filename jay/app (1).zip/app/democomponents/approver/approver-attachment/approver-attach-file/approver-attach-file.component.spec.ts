import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproverAttachFileComponent } from './approver-attach-file.component';

describe('ApproverAttachFileComponent', () => {
  let component: ApproverAttachFileComponent;
  let fixture: ComponentFixture<ApproverAttachFileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApproverAttachFileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproverAttachFileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
