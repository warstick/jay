import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproverAttachmentComponent } from './approver-attachment.component';

describe('ApproverAttachmentComponent', () => {
  let component: ApproverAttachmentComponent;
  let fixture: ComponentFixture<ApproverAttachmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApproverAttachmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproverAttachmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
