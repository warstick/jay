import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { Modal, ModalModule } from 'ngx-modal';
import { ReqDetails } from '../../../model/submitRequisition';
import { DivisionsService } from '../../../service/divisions.service';
import { Division } from '../../../model/division';

@Component({
  selector: 'app-approver-requisition-header',
  templateUrl: './approver-requisition-header.component.html',
  styleUrls: ['./approver-requisition-header.component.css']
})
export class ApproverRequisitionHeaderComponent implements OnInit {

  @ViewChild('viewComments') viewMsgsToModal: Modal;
  @ViewChild('viewAuditLogs') viewAuditModal: Modal;

  data: any = [];
  audits: any = [];
  isCollapsed: boolean;
  @Input() set collapsed(value: boolean) {
    this.isCollapsed = value;
  }

  @Input() set dropShip(value: boolean) {
    this.isDropShip = value;
  }

  @Input() set market(value: string) {
    this.marketNumber = value;
  }

  @Input() reqDetails: ReqDetails;
  requistionDetails: ReqDetails;
  marketNumber: string;

  @Output('showHide')
  showHide: EventEmitter<any> = new EventEmitter<any>();
  divisions: Division[];

  isDropShip: boolean;

  constructor(private divisionService: DivisionsService) { }

  ngOnInit() {
    this.requistionDetails = this.reqDetails;
    this.divisions = this.divisionService.getDivisions();
  }

  get collapsed(): boolean {
    return this.isCollapsed;
  }

  openViewComments() {
    if (!this.reqDetails.requisition.comments.length) {
      return;
    }
    this.viewMsgsToModal.open();
  }

  openAuditLog() {
    if (!this.reqDetails.auditLogs.length) {
      return;
    }
    this.viewAuditModal.open();
  }

  closeMsgModal() {
    this.viewMsgsToModal.close();
  }
  closeAuditModal() {
    this.viewAuditModal.close();
  }

  toggleCollapse() {
    this.showHide.emit(!this.isCollapsed);
  }
}
