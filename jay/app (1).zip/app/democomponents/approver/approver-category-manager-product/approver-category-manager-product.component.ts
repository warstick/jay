import { ApproverViewProductAttachmentsComponent } from './../approver-attachment/approver-view-product-attachments/approver-view-product-attachments.component';
import { ModelChangeUpdateEvents, ActionEvents } from './../../../events/action-events';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { BaseComponent } from './../../base-component';
import { ProductAttachmentComponent } from './../../common/product/product-attachment.component';
import { Component, OnInit,ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { TaskInboxProduct } from '../../../model/submitRequisition';
import { Modal, ModalModule } from 'ngx-modal';
import { ReqDetails } from '../../../model/submitRequisition';
import { ProductCommentComponent } from "app/democomponents/common/comment/product-comment/product-comment.component";

@Component({
  selector: 'app-approver-category-manager-product',
  templateUrl: './approver-category-manager-product.component.html',
  styleUrls: ['./approver-category-manager-product.component.css']
})

export class ApproverCategoryManagerProductComponent extends BaseComponent implements OnInit {
  @ViewChild('viewComments') viewMsgsToModal: Modal;
  @ViewChild('viewProduct') viewProdModal: Modal;
  @ViewChild('ProductComments') productComments: ProductCommentComponent; 
  @ViewChild('ViewProductAttachment') viewProductsComponent: ApproverViewProductAttachmentsComponent;
  @ViewChild('ProductAttachmentModal') productAttachmentModal: Modal;

  @Input() set collapsed(value: boolean) {
    this.isCollapsed = value;
  }

  @Input() set allReturned(value: boolean) {
    this.isAllReturned = value;
  }
  @Input() products: TaskInboxProduct[];
  @Input() reqDetails: ReqDetails;
  requistionDetails: ReqDetails;
  @Output('showHide')
  showHide: EventEmitter<any> = new EventEmitter<any>();
  @Output('return')
  return: EventEmitter<any> = new EventEmitter<any>();
  @Output('returnAll')
  returnAll: EventEmitter<any> = new EventEmitter<any>();
  @Output('updateProductNumber')
  updateProductNumber: EventEmitter<any> = new EventEmitter<any>();
  public attachmentsList:Array<any> = [];
  isCollapsed: boolean;
  comments: any[] = [];
  currentProd: any;
  isAllReturned: boolean;
  public reqNbr: string;

  constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
    super(stateRepresentationRendererService);
    let mapping: any = [];           
    mapping[ModelChangeUpdateEvents.PROD_ATTACH_DETAILS_SUCCESS] = (data) => { this.renderAttachmentDetails(data) }
    super.registerStateChangeEvents(mapping);
  }

  ngOnInit() {
  }

  get collapsed(): boolean {
    return this.isCollapsed;
  }

  toggleCollapse() {
    this.showHide.emit(!this.isCollapsed);
  }
  openViewComments(comments, index) {
    this.comments = comments || []
    if (!comments.length) {
      return;
    }
    this.viewMsgsToModal.open();
    this.productComments.newAddedCount = 0;
    this.productComments.comments = this.comments;
    this.productComments.productSeq = index + 1;
  }

  openViewAttachments(seq) {
    this.viewProductsComponent.attachmentsList = [];
    let event = this.actionDispatcherService.generateEvent(ActionEvents.PROD_ATTACHMENT_DETAILS, {requisitionId: this.reqNbr, attachmentKey:seq});
    this.actionDispatcherService.dispatch(event);
    this.viewProductsComponent.seqId = seq;
    this.productAttachmentModal.open();
  }

  openProd(product) {
    this.currentProd = product;
    this.viewProdModal.open();
  }

  closeMsgModal() {
    if(this.productComments.newAddFlag == true){
      //cancel without saving so clear out the first item of the comments array
      for(let i = 0; i < this.productComments.newAddedCount; i++){
        this.productComments.comments.shift();
      }
      //reset the add flag
      this.productComments.newAddFlag = false;
    }
    //clear error
    this.productComments.commentErr = false;
    this.viewMsgsToModal.close();
  }

  saveComment(){
      //validation first
      debugger
      if(this.productComments.commentErr == true){
        return;
      }
      //if user does not hit add, just close it
      if(this.productComments.newAddFlag == false){
        this.viewMsgsToModal.close();
      }else{
        this.productComments.newAddFlag = false;
        //save to comments array of product element
        this.products.forEach((product, index) => {
          if (product.seq == this.productComments.productSeq) {
            //will need to remove the empty text on the first element
            if(this.productComments.comments[0].commentsText == ''){
              this.productComments.comments.shift();
            }
            debugger
            product.comments = this.productComments.comments;
          }    
        });
        this.viewMsgsToModal.close();
      }
    }


  closeProdModal() {
    this.viewProdModal.close();
  }

  toggleReturnAll() {
    this.returnAll.emit({'products': this.products });
  }

  returnProduct(productId: 'string', returned: boolean) {
    this.return.emit({ 'productId': productId, 'returned': returned });
  }

  isAllProductsReturned() {
    this.products.forEach((product: TaskInboxProduct) => {
      console.log(product.returned);
    });
    return true;
  }

  handleProdNumBlur(productId, manufacturerId) {
    console.log(manufacturerId);
    this.updateProductNumber.emit({'productId': productId, 'manufacturerId': manufacturerId });
  }

  findInArray(array: any, property: string, value: any) {
    return array.filter((obj) => {
      return obj[property] === value;
    });
  }

  cancelProductAttchment(){
    this.productAttachmentModal.close();
  }

  downloadAll(){
    let event = this.actionDispatcherService.generateEvent(ActionEvents.PROD_ATTACHMENTS_MULTI_DOWNLOAD, {requisitionId: this.reqNbr, attachmentsList: this.attachmentsList, attachmentKey: this.viewProductsComponent.seqId });
    this.actionDispatcherService.dispatch(event);
  }

  renderAttachmentDetails(data) {
    console.log("Rendering Attachment Details: " + data[0].fileName);
    this.attachmentsList = data;
  }

}
