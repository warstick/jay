import { RouterModule } from '@angular/router';
import { AuthGuard } from '../util/auth.guard';
import { ApproverComponent } from "app/democomponents/approver/approver.component";
import { ApproverRequisitionHeaderComponent } from './approver-requisition-header/approver-requisition-header.component';

export const sodsApproverRoutes=[
    { path: '', component: ApproverComponent, canActivate: [AuthGuard] },
    { path: 'approver/:taskId', component: ApproverRequisitionHeaderComponent, canActivate: [AuthGuard]}
];

export const routing = RouterModule.forChild(sodsApproverRoutes);