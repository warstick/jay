import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproverChangeVendorComponent } from './approver-change-vendor.component';

describe('ApproverChangeVendorComponent', () => {
  let component: ApproverChangeVendorComponent;
  let fixture: ComponentFixture<ApproverChangeVendorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApproverChangeVendorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproverChangeVendorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
