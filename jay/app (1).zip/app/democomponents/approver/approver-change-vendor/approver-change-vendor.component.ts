import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approver-change-vendor',
  templateUrl: './approver-change-vendor.component.html',
  styleUrls: ['./approver-change-vendor.component.css']
})
export class ApproverChangeVendorComponent implements OnInit {

  public selectedVendor: string;
  public defaultVendor: string;
  private vendorOptions: string[] = ['Vendor1', 'Vendor2'];

  constructor() { }

  ngOnInit() {
  }

}
