import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproverProductAttachmentProdInfoComponent } from './approver-product-attachment-prod-info.component';

describe('ApproverProductAttachmentProdInfoComponent', () => {
  let component: ApproverProductAttachmentProdInfoComponent;
  let fixture: ComponentFixture<ApproverProductAttachmentProdInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApproverProductAttachmentProdInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproverProductAttachmentProdInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
