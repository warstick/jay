import { NgModule } from '@angular/core';
import { ViewAttachmentsComponent } from './viewattachments.component';
import { CommonModule } from '@angular/common';
import { SharedModule } from "app/shared/shared.module";
import { routing } from "app/democomponents/sodstaskinbox/sodstaskinbox.routes";
import { SodstaskinboxComponent } from "app/democomponents/sodstaskinbox/sodstaskinbox.component";
import { OrderrByPipe } from "app/democomponents/util/orderby.pipe";
import { InboxCommentComponent } from './inbox-comment/inbox-comment.component';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    NgxPaginationModule,
    routing
  ],
  declarations: [
    SodstaskinboxComponent,
    OrderrByPipe,
    InboxCommentComponent,
    ViewAttachmentsComponent,
  ]


})
export class SodstaskinboxModule { }
