import { Component, OnInit } from '@angular/core';
import { Comment, SAMPLECommentA, SAMPLECommentB } from '../../../model/comment';

@Component({
  selector: 'app-inbox-comment',
  templateUrl: './inbox-comment.component.html',
  styleUrls: ['./inbox-comment.component.css']
})
export class InboxCommentComponent implements OnInit {

  public comments: Array<Comment> = [];
  public newAddFlag: boolean = false;
  public productSeq: number;
  public newAddedCount: number = 0;

  private textareaLength: number = 1000;
  maxIncidentDescriptionLength: any = 1000;

  constructor() { }

  ngOnInit() {

  }

}
