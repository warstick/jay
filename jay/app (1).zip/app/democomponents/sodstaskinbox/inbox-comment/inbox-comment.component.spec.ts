import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InboxCommentComponent } from './inbox-comment.component';

describe('InboxCommentComponent', () => {
  let component: InboxCommentComponent;
  let fixture: ComponentFixture<InboxCommentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InboxCommentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InboxCommentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
