import { Attachment } from './../../model/attachment';
import { ViewAttachmentsComponent } from './viewattachments.component';
import { BaseComponent } from './../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';

import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';

import { ActionEvents, ModelChangeUpdateEvents } from "../../events/action-events";
import { Task } from "app/model/task";
import { Modal, ModalModule } from 'ngx-modal';
import { InboxCommentComponent } from "app/democomponents/sodstaskinbox/inbox-comment/inbox-comment.component";
import { PaginationInstance } from "ngx-pagination/dist/ngx-pagination";
import { Router } from '@angular/router';
import { DivisionsService } from '../../service/divisions.service';
import { Idle } from "@ng-idle/core";

import {OutOfService} from '../../service/outoffice.service';



@Component({
  selector: 'app-sodstaskinbox',
  templateUrl: './sodstaskinbox.component.html',
  styleUrls: ['./sodstaskinbox.component.css']
})

export class SodstaskinboxComponent extends BaseComponent implements OnInit, AfterViewInit {

  public taskList: Array<Task> = [];
  public attachList:Array<Attachment> = [];
  //for pagination
  pageOptions: string[];
  selectedPage: string;
  readonly defaultPage: string = "View 10";

  @ViewChild('ViewAttachments')
  viewAttachmentsComponent: ViewAttachmentsComponent;

  @ViewChild('ViewAttachmentsModal')
  viewAttachmentsModal: Modal;

  @ViewChild('successPopup')
  viewdraftSuccessModal: Modal;

  
  isDesc: boolean = true;
  column: string = 'taskId';
  successId: any;
  saveId: any;
  direction: number;

  //pagination
  p: number = 1;
  public config: PaginationInstance = {
    id: 'custom',
    itemsPerPage: 10,
    currentPage: 1
  };

  @ViewChild('InboxCommentModel')
  inboxCommentModel: Modal;

  @ViewChild('InboxComments')
  inboxComments: InboxCommentComponent;
  selectedType: any;
  forwardTask: any;
  value: any;
  networkId: any;


  constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService, private router: Router, private idle: Idle,
  public outOfService :OutOfService) {
    super(stateRepresentationRendererService);
    let mapping: any = [];
    mapping[ModelChangeUpdateEvents.GET_TASK_SUCCESS] = (taskList: Task[]) => { this.renderTasksLoadedSuccess(taskList); }
    mapping[ModelChangeUpdateEvents.RETRIEVE_COMMENT_INBOX_SUCCESS] = (commentsList: any) => { this.renderRetrieveCommentsSuccess(commentsList); }

    // For loading the approvers by role for a given market
    mapping[ModelChangeUpdateEvents.GET_OUT_OF_OFFICE_STATUS_SUCCESS] = (data: any) => {
        this.onGetOutofOfficeSuccess(data);
    };

    mapping[ModelChangeUpdateEvents.GET_OUT_OF_OFFICE_STATUS_FAIL] = (data: any) => {
        this.onGetOutofOfficeFail(data);
    };

    super.registerStateChangeEvents(mapping);
  }

  onGetOutofOfficeSuccess(data) {
    console.log(data);
    this.selectedType = (data.outOfOffice) ? 'outOfOffice' : 'inOffice';
    this.forwardTask = data.designateName;
    this.value = (data.returnDate) ? new Date(data.returnDate) : new Date();
  }
  onGetOutofOfficeFail(err) {

  }

  getBasicInfo() {
    const event = this.actionDispatcherService.generateEvent(
          ActionEvents.GET_OUT_OF_OFFICE_STATUS, this.networkId
      );
      this.actionDispatcherService.dispatch(event);
  }  

  ngOnInit() {
    this.pageOptions = ['View 10', 'View 50', 'View 100', 'View All'];
    this.idle.watch();
    this.networkId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
    this.getBasicInfo();
        

    this.getTaskInbox();
  }

  ngAfterViewInit() {
    if (localStorage.getItem('draftId') && localStorage.getItem('draftId') !== 'null') {
      this.successId = localStorage.getItem('draftId');
    }

    if (localStorage.getItem('saveId') && localStorage.getItem('saveId') !== 'null') {
      this.saveId = localStorage.getItem('saveId');
    }

    localStorage.setItem('draftId', null);
    localStorage.setItem('saveId', null);
  }

  onPageSelection($event){
    if($event == 'View All'){
      this.config.itemsPerPage = this.taskList.length;
    }else if($event == 'View 50'){
      this.config.itemsPerPage = 50;
    }else if($event == 'View 100'){
      this.config.itemsPerPage = 100;
    }else{
      this.config.itemsPerPage = 10;
    }
  }

  getTaskInbox() {
    //get the login network id from local storage
    const data = localStorage.getItem('user');
    const networkId = JSON.parse(JSON.parse(data)._body).userId;
    //make an api call from sam
    let event = this.actionDispatcherService.generateEvent(ActionEvents.GET_TASK, networkId);
    this.actionDispatcherService.dispatch(event);
  }

  renderTasksLoadedSuccess(taskList: Task[]) {
    //for testing, print out the task list
    this.taskList = taskList;
    this.sort('taskId');
  }

  sort(property) {
    this.isDesc = !this.isDesc; //change the direction    
    this.column = property;
    this.direction = this.isDesc ? 1 : -1;
  };

  export() {
    let event = this.actionDispatcherService.generateEvent(ActionEvents.EXPORT_EXCEL, {});
    this.actionDispatcherService.dispatch(event);
  }

  openComments(reqId: string) {
    let event = this.actionDispatcherService.generateEvent(ActionEvents.RETRIEVE_COMMENT_INBOX, reqId);
    this.actionDispatcherService.dispatch(event);
  }

  renderRetrieveCommentsSuccess(commentsList: any) {
    this.inboxComments.comments = commentsList;
    this.inboxCommentModel.open();
  }

  closeComment() {
    this.inboxCommentModel.close();
  }

  openViewAttachments(reqId: number) {
    this.viewAttachmentsComponent.requisitionId = reqId;
    let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENT_DETAILS, { requisitionId: reqId });
    this.actionDispatcherService.dispatch(event);
    this.viewAttachmentsModal.open();
  }

  cancelViewAttachments() {
    this.viewAttachmentsComponent.requisitionId = null;
    this.viewAttachmentsComponent.attachmentsList = null;
    this.viewAttachmentsModal.close();
  }

  downloadAll() {
    let reqId = this.viewAttachmentsComponent.requisitionId;
    this.attachList = this.viewAttachmentsComponent.attachmentsList;
    let event = this.actionDispatcherService.generateEvent(ActionEvents.REQ_ATTACHMENTS_MULTI_DOWNLOAD, { requisitionId: reqId, multiDownloadList: this.attachList });
    this.actionDispatcherService.dispatch(event);
  }

  openReqDetails(id) {
    var foundItem = this.taskList.find((item) => {
      return item.reqId === id;
    });
    console.log(foundItem);
    console.log(id);

    if (foundItem) {
      this.openTaskDetails(foundItem.taskId);
    }
  }

  moveToOutOfOffice() {
    this.router.navigateByUrl('outofoffice');
  }

  openTaskDetails(taskId: string) {
    this.router.navigate(['/approver'], { queryParams: { taskId: taskId } });
  }
}
