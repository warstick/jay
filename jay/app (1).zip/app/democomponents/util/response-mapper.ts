import { Customer } from '../../model/customer';
import { Product, Vendor, ShipToDist } from '../../model/product';
import { TandemTM } from '../../model/tandemTM';
import { ReqDetails, TaskInboxCustomer, TaskInboxProduct } from '../../model/submitRequisition';

export class ResponseMapper {
    static requistionTypes: any = {
        'SODS-SO': 'Special Order',
        'SODS-DS': 'Drop Ship'
    };

    static shipMethodTypes: any = {
        'Next': 'Next',
        'Separate': 'Separate'
    };

    static mapCustomer(data: any): Customer {
        let customer: Customer = new Customer();
        customer.id = data.custNbr;
        customer.division = data.div;
        customer.name = data.custNm;
        customer.address1 = data.addr.addr1;
        customer.address2 = data.addr.addr2;
        customer.city = data.addr.cty;
        customer.state = data.addr.ste;
        customer.zip = data.addr.zip;
        customer.phone = data.phone.telNbr;
        customer.estimatedOrderAmt = '321.12';
        customer.confidenceCode = data.creditCd;
        customer.creditCheckStatus = 'true';
        customer.tmId = data.rte.tmId;
        customer.tmName = 'sodsus02, SharedAcct';
        customer.tmEmail = 'Shared.sodsus02@foodfite.com';
        customer.deptOptions = this.buildOptions(data.dept || []);
        customer.custType = data.custTyp;
        return customer;
    }

    static mapProduct(data: any): Product{
        debugger
        let product: Product = new Product();
        let vendor : Vendor = new Vendor();
        product.vendor = vendor;
        product.description = data.desc;
        product.productId = data.prodNbr;
        product.mfrId = data.mfrProdNbr;
        product.distSts = data.distSts;
        product.label = data.label;
        product.priceUOM = data.priceUOM;
        product.packSize = data.slsPkSize;
        product.netWeight = data.netWght;
        product.salesUOM = data.slsUOM;
        product.catchWeightInd = data.catchWghtInd;
        product.vendor.vendorId = data.primVndrDtl.vndrNbr;
        product.vendor.vendorName = data.primVndrDtl.vndrNm;
        product.vendor.vendorLstPrc = data.primVndrDtl.vndrLstPrc;
        product.vendor.buyerNumber = data.primVndrDtl.byrNbr;
        product.vendor.buyerEmail = data.primVndrDtl.byrEmail;
        product.vendor.buyerName = data.primVndrDtl.byrNm;
        product.vendor.buyerNetworkId = data.primVndrDtl.byrUsrID;
        product.prodCnt = data.prodCnt;
        //add converter
        product.convFctr = data.convFctr;
        product.ntnlSts = data.ntnlSts;
        product.prodAttchd = data.prodAttchd;
        // product.attached = data.prodAttchd;
        if(data.prodAttchd == 'T'){
            product.attached = 'true';
        }else if(data.prodAttchd == 'F'){
            product.attached = 'false';
        }else{
            product.attached = data.prodAttchd;
        }
        product.class = data.pimClass;
        product.pimClass = data.pimClass;
        return product;
    }

    static mapTMInfo(data: any): TandemTM{
        let tandemTM: TandemTM = new TandemTM();
        tandemTM.routeToDivision = data.routeToDivision;
        tandemTM.routeToDivisionCode = data.routeToDivisionCode;
        tandemTM.routeToDivisionSystem = data.routeToDivisionSystem;
        tandemTM.routeToDivisionTimezone = data.routeToDivisionTimezone;
        tandemTM.routeToDSMID = data.routeToDSMID;
        tandemTM.routeToFMID = data.routeToFMID;
        tandemTM.routeToRSMID = data.routeToRSMID;
        tandemTM.routeToVPID = data.routeToVPID;
        tandemTM.status = data.status;
        tandemTM.statusDescription = data.statusDescription;
        tandemTM.tmnetworkID = data.tmnetworkID;
        tandemTM.tmparentDivision = data.tmparentDivision;
        return tandemTM;
    }

    private static buildOptions(dept: any): string[] {
        let optionList: string[] = [];

        for(let i = 0; i < dept.length; i++) {
            let entry = dept[i];
            let department = entry.dptNbr.concat('-'.concat(entry.dptNm));
            optionList.push(department);
        }
        return optionList;
    }

    static mapRequisitionDetails(response: ReqDetails): ReqDetails {
        const reqDetails: ReqDetails = new ReqDetails();

        reqDetails.draftTaskId = response.draftTaskId || '';
        reqDetails.overideSavedByID = response.overideSavedByID || '';
        reqDetails.overideSavedByName = response.overideSavedByName || '';
        reqDetails.taskId = response.taskId || '';
        reqDetails.taskName = response.taskName || '';
        reqDetails.taskStatus = response.taskStatus || '';
        reqDetails.responseStatus = response.responseStatus || '';
        reqDetails.assignedToCount = response.assignedToCount || '';
        reqDetails.assignedToList = response.assignedToList || [];

        // requisition
        reqDetails.requisition.comments = response.requisition.comments || [];
        reqDetails.requisition.createdAt = response.requisition.createdAt || '';
        reqDetails.requisition.defaultCustomerPO = response.requisition.defaultCustomerPO || '';
        reqDetails.requisition.defaultShipMethod = this.shipMethodTypes[response.requisition.defaultShipMethod] || '';
        reqDetails.requisition.defaultSpecInstructions = response.requisition.defaultSpecInstructions || '';
        reqDetails.requisition.mainCustomerType = response.requisition.mainCustomerType || '';
        reqDetails.requisition.division = response.requisition.division || '';
        reqDetails.requisition.ETADate = response.requisition.ETADate || '';
        reqDetails.requisition.ETASelection = response.requisition.ETASelection || false;
        reqDetails.requisition.mainCustomerDept = response.requisition.mainCustomerDept || '';
        reqDetails.requisition.mainCustomerID = response.requisition.mainCustomerID || '';
        reqDetails.requisition.mainCustomerName = response.requisition.mainCustomerName || '';
        reqDetails.requisition.quoteNumber = response.requisition.quoteNumber || '';
        reqDetails.requisition.quotePrice = response.requisition.quotePrice || '';
        reqDetails.requisition.requisitionNumber = response.requisition.requisitionNumber || '';
        reqDetails.requisition.requisitionType = this.requistionTypes[response.requisition.requisitionType];
        reqDetails.requisition.returnIfETANotMet = response.requisition.returnIfETANotMet || false;
        reqDetails.requisition.status = response.requisition.status || '';
        reqDetails.requisition.totalAmount = response.requisition.totalAmount || '';
        reqDetails.requisition.updatedAt = response.requisition.updatedAt || '';

        // requestor
        reqDetails.requestor.additionalEmail = response.requestor.additionalEmail || '';
        reqDetails.requestor.additionalPhone = response.requestor.additionalPhone || '';
        reqDetails.requestor.email = response.requestor.email || '';
        reqDetails.requestor.name = response.requestor.name || '';
        reqDetails.requestor.networkId = response.requestor.networkId || '';

        // territory manager
        reqDetails.territoryManager.additionalEmail = response.territoryManager.additionalEmail || '';
        reqDetails.territoryManager.additionalPhone = response.territoryManager.additionalPhone || '';
        reqDetails.territoryManager.email = response.territoryManager.email || '';
        reqDetails.territoryManager.name = response.territoryManager.name || '';
        reqDetails.territoryManager.networkId = response.territoryManager.networkId || '';

        // customers
        let customers: TaskInboxCustomer[] = new Array<TaskInboxCustomer>();
        response.customers.forEach((customer) => {
            customer.zip = this.formatZipCode(customer.zip);
            customer.phone = this.formatPhoneNum(customer.phone);
            customer.defaultShipMethod = this.shipMethodTypes[customer.defaultShipMethod];
            customers.push(customer);
        });
        reqDetails.customers = customers;

        // products
        let products: TaskInboxProduct[] = new Array<TaskInboxProduct>();
        response.products.forEach((product: TaskInboxProduct) => {
            product.shipTodistribution[0].shipMethod = this.shipMethodTypes[product.shipTodistribution[0].shipMethod];
            if (!product.returned) {
                product.returned = false;
            }
            products.push(product);
        });
        reqDetails.products = products;
        reqDetails.auditLogs = response.auditLogs;
        return reqDetails;
    }

    static formatZipCode(zipcode) {
        return zipcode.replace(/(\d{5})(\d{4})/, '$1-$2');
    }

    static formatPhoneNum(phone) {
        return phone.replace(/(\d{3})(\d{3})(\d{3})/, '($1) $2-$3');
    }
}