import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';

@Injectable()
export class AuthGuard implements CanActivate{

    private useJWT = false;
    constructor(private router: Router){

    }

    canActivate(){
        console.log("calling canActivate of auth guard");
        if(this.useJWT){
            
        }else{
            //TODO: implement the authentication logic
            let record = JSON.parse(localStorage.getItem('token'));
            if(!record){
                this.router.navigate(['/']);
                return false;
            }
            let token = record.value;
            let expiration = record.timestamp;

            if(expiration > new Date().getTime()){
                console.log("Token is not expired");
                return true;
            }else{
                this.router.navigate(['/']);
                return false;
            }
        }
        this.router.navigate(['/']);
        return false;
    }
}