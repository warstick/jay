import { ReqDetails, Requisition, Comment, Requestor, TerritoryManager, TaskInboxCustomer, TaskInboxProduct, Requested, TaskInboxVendor, ShipTodistribution } from '../../model/submitRequisition';

export class SubmitResponseMapper {
    mapSubmitReqMapper(data) {
        const submitReq = new ReqDetails();
        submitReq.draftTaskId = data.draftTaskId;
        submitReq.requisition = data.requisition;
        submitReq.requestor = data.requestor;
        submitReq.territoryManager = data.territoryManager;
        submitReq.customers = data.customers;
        submitReq.products = data.products;
        return submitReq;
    }

    mapDraftReqMapper(data) {
        const submitReq = new ReqDetails();
        submitReq.requisition = data.requisition;
        submitReq.requestor = data.requestor;
        submitReq.territoryManager = data.territoryManager;
        submitReq.customers = data.customers;
        submitReq.products = data.products;
        submitReq.overideSavedByID = data.overideSavedByID;
        submitReq.overideSavedByName = data.overideSavedByName;
        return submitReq;
    }
}