import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Pipe({
    name: 'dateFormatPipe',
})
export class dateFormatPipe implements PipeTransform {
    transform(value: string) {
        var dateStr = value.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
        dateStr = dateStr.replace('-','/');
        var date = new Date(dateStr + '+0000');
        console.log(date.toLocaleString());
        console.log(date.toString().replace(/.*[(](.*)[)].*/,'$1'));
        return date.toLocaleString() + ' ' + date.toString().replace(/.*[(](.*)[)].*/,'$1').replace('Pacific Standard Time','PST').replace('Central Standard Time','CST')
            .replace('Mountain Standard Time', 'MST').replace('Eastern Standard Time', 'EST');
    }
}