import { UnsetOutOfOffice, SetOutOfOffice, UnsetOutOfOfficeContent, SetOutOfOfficeContent } from '../../model/outofoffice';

export class RequestMapper {

    static mapUnsetOutofOffice(data: any): UnsetOutOfOffice {
        
        let unsetOutOfOffice: UnsetOutOfOffice = new UnsetOutOfOffice();
        let unsetOutOfOfficeContent: UnsetOutOfOfficeContent = new UnsetOutOfOfficeContent();

        unsetOutOfOfficeContent.NetworkID = data.networkId;
        unsetOutOfOffice.unsetOoOrequest = unsetOutOfOfficeContent;
        return unsetOutOfOffice;
    }

    
    static mapSetOutofOffice(data: any): SetOutOfOffice {

        const date = data.val;
        debugger
        let setOutOfOffice: SetOutOfOffice = new SetOutOfOffice();
        let setOutOfOfficeContent: SetOutOfOfficeContent = new SetOutOfOfficeContent();
        setOutOfOfficeContent.OutOfOfficeUserID = (data.updateType === 'outOfOffice') ? data.networkId : ((data.updateType === 'setOtherUser') ? (data.otherUser || {}).userID : '');
        setOutOfOfficeContent.updatedByUserID = data.networkId;
        setOutOfOfficeContent.ReturnDate = date.getFullYear() + "-" + ((date.getMonth() + 1 <= 9) ? '0' : '') + (date.getMonth() + 1) + "-" + ((date.getDate() <= 9) ? '0' : '') + (date.getDate()); 
        setOutOfOfficeContent.DesignateID = (data.updateType === 'setOtherUser' || data.updateType === 'outOfOffice') ? (data.forwardTaskUser || {}).userID : '';
        setOutOfOfficeContent.SuperUserID = (data.updateType === 'setOtherUser') ? data.networkId : undefined
        setOutOfOffice.setOoOrequest = setOutOfOfficeContent;
        return setOutOfOffice;
    }

}