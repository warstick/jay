import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder
} from '@angular/forms';
import { Http, Headers } from '@angular/http';
import { contentHeaders } from '../util/headers';
import { AuthenticationService } from '../../service/authentication.service';

import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';

import { Modal, ModalModule } from 'ngx-modal';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})

export class LoginComponent implements OnInit {
  public error: Boolean;
  myform: FormGroup;
  username: FormControl;
  password: FormControl;
  actionCompleted: boolean = true;

  idleState = 'Not started.';
  timedOut = false;
  lastPing?: Date = null;

  @ViewChild('removeLocation') removeLocationModal: Modal;

  constructor(public router: Router, public http: Http,
    private authService: AuthenticationService, private idle: Idle, private keepalive: Keepalive) { }

  ngOnInit() {
    this.error = false;
    //this.removeLocationModal.open();
    this.username = new FormControl('', Validators.required);
    this.password = new FormControl('', Validators.required);

    this.myform = new FormGroup({
      username: this.username,
      password: this.password
    });
  }

  login(event, username, password) {
    this.actionCompleted = false;
    this.authService.loginService(username, password).subscribe(response => {
      if (response.json().token != null && response.json().token != undefined && response.json().login == 'SUCCESS') {

        let obj = { "token": response.json().token };
        sessionStorage.setItem('token_obj', JSON.stringify(obj));
        sessionStorage.setItem('token', response.json().token);
        let expiration = new Date().getTime() + 30 * 60 * 1000;
        let record = { value: response.json().token, timestamp: expiration }
        localStorage.setItem('token', JSON.stringify(record));

        //login comp
        this.idle.setIdle(240); //4 minutes for testing
        this.idle.setTimeout(120); // 2 minutes for testing

        this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
       
        this.idle.onTimeoutWarning.subscribe((countdown) => this.idleState = 'You will time out in ' + countdown + ' seconds!');

        this.keepalive.interval(1800);

        this.reset();

        //Calls JWT parsing API for user info
        this.authService.fetchUser().subscribe(resp => {
          localStorage.setItem('user', JSON.stringify(resp));
          //if login success, store the username/password into the localstorage
          localStorage.setItem('username', username);
          localStorage.setItem('password', password);
          this.router.navigateByUrl('/taskInbox');
        });
      } else {
        this.actionCompleted = true;
        this.error = true;
      }
    });
  }
  reset() {
    //this.idle.watch();
    this.idleState = 'Started.';
    this.timedOut = false;
  }

  cancel() {
    //logout
      sessionStorage.removeItem('token'); 
       localStorage.removeItem('token');
       this.router.navigateByUrl('/#');
  }

}