import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { Http, Headers } from '@angular/http';
import { contentHeaders } from '../util/headers'; 
import { Idle } from "@ng-idle/core";


@Component({
    selector: 'logoff',
    templateUrl: './logoff.component.html',
    styles: [ './logoff.component.css' ]
})

export class LogOffComponent implements OnInit{

    constructor(public router: Router, public http: Http, public idle: Idle){
        console.log("constructor of logoff");
    }

    ngOnInit(){
       this.idle.stop();
       sessionStorage.removeItem('token'); 
       localStorage.removeItem('token');
       this.router.navigateByUrl('/#');
    }

}