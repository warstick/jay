import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { BaseComponent } from '../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from "../../events/action-events";
import { UsfUser } from '../../model/usfuser';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  // encapsulation: ViewEncapsulation.Native

})
export class HeaderComponent extends BaseComponent implements OnInit {

  username: string;

  constructor(readonly actionDispatcherService: ActionDispatcherService, 
    readonly stateRepresentationRendererService: StateRepresentationRendererService,
  ) { 
    super(stateRepresentationRendererService);
  }

  ngOnInit() {    
    let mapping: any = [];
    mapping[ModelChangeUpdateEvents.USER_INFO_FOUND] = (data: UsfUser) => { this.renderUsername(data); }
    mapping[ModelChangeUpdateEvents.USER_INFO_NOT_FOUND] = (error: any) => { }
    super.registerStateChangeEvents(mapping);
    this.instantiateUser();
  }

  public renderUsername(user: UsfUser) {
    this.username = user.lastName.concat(" " + user.firstName);
  }

  private instantiateUser() {
    try{
        console.log("Fetching user information");
    let token = sessionStorage.getItem('token');
    let event = this.actionDispatcherService.generateEvent('retrieveUserInfo', {});
    this.actionDispatcherService.dispatch(event);
    }catch(err) {}
    
  }
}