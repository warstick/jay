import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SodsdetailsComponent } from './sodsdetails.component';

describe('SodsdetailsComponent', () => {
  let component: SodsdetailsComponent;
  let fixture: ComponentFixture<SodsdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SodsdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SodsdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
