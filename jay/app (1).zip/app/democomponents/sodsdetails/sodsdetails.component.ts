import {Component, OnInit, ViewChild, AfterContentInit} from '@angular/core'; 
import { ActivatedRoute, Router, Params } from '@angular/router';

import { BaseComponent } from '../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from "../../events/action-events";


import { CustomerComponent } from '../common/customer/customer.component';
import { Requisition } from '../../model/requisition';

@Component({
  selector: 'app-sodsdetails',
  templateUrl: './sodsdetails.component.html',
  styleUrls: ['./sodsdetails.component.css']
})
export class SodsdetailsComponent extends BaseComponent implements OnInit, AfterContentInit  {

  public id: string;

  //Children - Customer
  @ViewChild(CustomerComponent)
  private customerComponent : CustomerComponent;

  constructor(public activeRoute: ActivatedRoute, readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
        super(stateRepresentationRendererService);

        let mapping: any = [];
        
        mapping[ModelChangeUpdateEvents.REQ_FOUNT] = (data: Requisition) => {
            this.renderReqFound(data);
        }

        mapping[ModelChangeUpdateEvents.REQ_NOT_FOUND] = (error: any) => {

        }

        super.registerStateChangeEvents(mapping);
   }

    ngOnInit() {
        this.activeRoute.params.subscribe(params => {
            console.log(params.reqId);
            this.id = params.reqId;
            let event = this.actionDispatcherService.generateEvent('sodsRequestToLoadReq', {reqId: this.id});
            this.actionDispatcherService.dispatch(event);
        });
    }

    ngAfterContentInit(){
        this.customerComponent.readOnly = true;
        this.customerComponent.retrieveSuccess = true;
    }


    renderReqFound(req: Requisition){
        
        this.customerComponent.id = req.customer.id;
        this.customerComponent.dept = req.customer.dept;
        this.customerComponent.city = req.customer.city;
        this.customerComponent.division = req.customer.division;
        this.customerComponent.defaultShipMethod = req.customer.defaultShipMethod;
        this.customerComponent.state = req.customer.state;
        this.customerComponent.name = req.customer.name;
        this.customerComponent.phone = req.customer.phone;
        this.customerComponent.address1 = req.customer.address1;
        this.customerComponent.address2 = req.customer.address2;

    }

  

}
