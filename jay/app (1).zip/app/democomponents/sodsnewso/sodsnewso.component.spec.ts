import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SODSNewSoComponent } from './sodsnewso.component';
import { ActionDispatcherService, StateRepresentationRendererService, ModelPresenterService, EventTypeRegistryService } from 'usf-sam';


describe('Sodsnewso1Component', () => {
  let component: SODSNewSoComponent;
  let fixture: ComponentFixture<SODSNewSoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SODSNewSoComponent ],
      providers:[
        ActionDispatcherService, 
        ModelPresenterService,
        StateRepresentationRendererService,
        EventTypeRegistryService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SODSNewSoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
