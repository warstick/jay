import { Injectable } from '@angular/core';
import { Division } from '../model/division';

@Injectable()
export class DivisionsService {
    divisions: Division[];

    setDivisions(divisions: Array<Division>) {
        this.divisions = divisions;
    }

    getDivisions() {
        return this.divisions;
    }
}
