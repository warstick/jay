import { observable } from 'rxjs/symbol/observable';
import { Injectable } from '@angular/core';
import { Event } from 'usf-sam';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { contentHeaders } from '../democomponents/util/headers';
import { ActionDispatcherService } from 'usf-sam';
import { Observable, Subject} from 'rxjs/Rx';
import { environment } from '../../environments/environment';

@Injectable()
export class OutOfService {

  // Resolve HTTP using the constructor
  constructor(private http: Http, readonly actionDispatcherService: ActionDispatcherService) { }

  loginService(username, password): Observable<any> {       
      let body = JSON.stringify({username, password});
      return this.http.post(environment.loginURL, body, {headers: contentHeaders});
  }

  getTasks(networkId): Observable<any>
  {
    return this.http.get(environment.getTasksURL+'/'+networkId) ;

  }

  fetchUser(): Observable<any>  {
    console.log("Fetching user information");
    let token = sessionStorage.getItem('token_obj');
    return this.http.post(environment.tokenParserURL, token, {headers: contentHeaders});
  }
}